using System;
using System.Windows;
using System.Windows.Threading;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media;
using System.Text.RegularExpressions;
using System.Windows.Documents;
using System.Windows.Input;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Reflection;
using System.Windows.Interop;
using PowerPointApp = Microsoft.Office.Interop.PowerPoint.Application;
using PowerPointPresentation = Microsoft.Office.Interop.PowerPoint.Presentation;
using Microsoft.Office.Interop.PowerPoint;
using System.Configuration;
using Libraries.Group1;
using Libraries;

namespace MOS_PowerPoint_app.Views
{
    /// <summary>
    /// UiTestAppBarWindow.xaml の相互作用ロジック（PowerPointアプリ用）
    /// </summary>
    public partial class UiTestAppBarWindow : System.Windows.Window
    {
        // Windows API用の定義
        [DllImport("user32.dll")]
        static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
        
        [DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
        
        [DllImport("user32.dll")]
        static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);
        
        [DllImport("user32.dll")]
        static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        
        [DllImport("user32.dll")]
        static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);
        
        [DllImport("user32.dll")]
        static extern bool EnumWindows(EnumWindowsProc enumProc, IntPtr lParam);
        
        delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        
        [StructLayout(LayoutKind.Sequential)]
        struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }
        private DispatcherTimer _timer;
        private TimeSpan _remainingTime;
        private int _currentProjectId = 1;
        private int _currentTaskId = 1;
        private int _groupId = 1; // グループIDを保存
        private List<TaskInfo> _tasks;
        private ProjectData _projectData;
        private Dictionary<int, bool[]> _projectTaskCompletedStates = new Dictionary<int, bool[]>(); // プロジェクトごとの解答済み状態
        private Dictionary<int, bool[]> _projectTaskFlaggedStates = new Dictionary<int, bool[]>(); // プロジェクトごとのフラグ状態
        private Dictionary<int, bool[]> _projectTaskViewedStates = new Dictionary<int, bool[]>(); // プロジェクトごとの閲覧状態（未読問題の追跡用）
        private DateTime _projectStartTime; // プロジェクト開始時刻
        private DispatcherTimer _projectTimer; // プロジェクト用タイマー（5分制限）
        private Dictionary<int, Dictionary<int, string>> _clipboardTargets = new Dictionary<int, Dictionary<int, string>>(); // クリップボード対象（プロジェクトID → タスクID → 問題文）
        private bool _isPaused = false; // 一時停止状態
        private DateTime _pauseStartTime; // 一時停止開始時刻（プロジェクトタイマー用）
        private List<System.Windows.Controls.Button> _dynamicTaskButtons = new List<System.Windows.Controls.Button>(); // 動的に生成されたタスクボタン（8番目以降）
        private readonly Action _onScoreClick; // 採点ボタン押下時（プロジェクト一覧の採点と同じ処理を実行）
        private DispatcherTimer _slideMonitorTimer; // Task 4 用: スライド ID 監視（1秒間隔）
        private bool _fromResultWindow = false; // 結果画面からタスクに飛んできたかどうか
        private ResultWindow _resultWindow = null; // 結果画面への参照
        private readonly HashSet<string> _initialWrongTaskKeys = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _retryTaskKeys = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _preparedRetryTaskKeys = new HashSet<string>(StringComparer.Ordinal);
        
        public UiTestAppBarWindow(int projectId = 1, int groupId = 1, bool showScoreButton = false, bool showPauseButton = false, Action onScoreClick = null)
        {
            InitializeComponent();
            _currentProjectId = projectId;
            _groupId = groupId; // グループIDを保存
            _onScoreClick = onScoreClick;
            var scoreBtn = FindName("ScoreButton") as System.Windows.Controls.Button;
            if (scoreBtn != null)
                scoreBtn.Visibility = showScoreButton ? Visibility.Visible : Visibility.Collapsed;
            var pauseBtn = FindName("PauseButton") as System.Windows.Controls.Button;
            if (pauseBtn != null)
                pauseBtn.Visibility = showPauseButton ? Visibility.Visible : Visibility.Collapsed;
            InitializeTimer();
            InitializeProjectTimer();
            InitializeSlideMonitor();
            LoadClipboardTargets(); // クリップボード対象を先に読み込む
            LoadTasks();
            UpdateTaskDisplay();
            WriteCurrentTaskFile();
            SetWindowPosition();
            // 注意: PowerPointプレゼンテーションはMainViewModelのExecuteOpenProjectで既に開かれている
            // ここでは開かない（PositionPowerPointWindowはSetWindowPositionで呼ばれる）
        }
        
        private void SetWindowPosition()
        {
            // PowerPointウィンドウを配置
            PositionPowerPointWindow();
            
            // ウィンドウハンドルを取得
            IntPtr hWnd = new WindowInteropHelper(this).Handle;
            if (hWnd == IntPtr.Zero)
            {
                // ハンドルが取得できない場合はWPFプロパティで設定
                this.Width = 1920;
                this.Height = 258;
                this.Left = 0;
                this.Top = 774;
                this.Topmost = true;
                return;
            }

            // 現在のウィンドウサイズを取得して境界線のサイズを計算
            GetWindowRect(hWnd, out RECT windowRect);
            GetClientRect(hWnd, out RECT clientRect);

            int borderWidth = (windowRect.right - windowRect.left) - clientRect.right;
            int borderHeight = (windowRect.bottom - windowRect.top) - clientRect.bottom;

            // アプリバーのウィンドウを1920x258サイズで、PowerPointの下に配置
            // 高さ: 258 (1032 / 4)
            // 位置: Y=774 (PowerPointの下)
            // 境界線を考慮して位置を調整
            int x = -borderWidth / 2; // 左側の境界線を考慮
            int y = 774 - borderHeight / 2; // 上側の境界線を考慮（PowerPointの下）
            int width = 1920 + borderWidth; // 境界線を含めた幅
            int height = 258 + borderHeight; // 境界線を含めた高さ

            MoveWindow(hWnd, x, y, width, height, true);
            
            // ウィンドウを最前面に表示
            this.Topmost = true;
        }
        
        private void PositionPowerPointWindow()
        {
            // リトライ＋Sleep を UI スレッドで行うとフリーズするため、バックグラウンドで実行する
            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var pptProcesses = Process.GetProcessesByName("POWERPNT");
                    if (pptProcesses.Length == 0)
                    {
                        System.Diagnostics.Debug.WriteLine("[AppBarWindow] PowerPoint process not found");
                        return;
                    }

                    IntPtr pptHwnd = IntPtr.Zero;
                    uint processId = 0;
                    using (Process pptProcess = pptProcesses[0])
                    {
                        processId = (uint)pptProcess.Id;
                        int retryCount = 0;
                        const int maxRetries = 20;

                        while (pptHwnd == IntPtr.Zero && retryCount < maxRetries)
                        {
                            EnumWindows((windowHandle, lParam) =>
                            {
                                GetWindowThreadProcessId(windowHandle, out uint windowProcessId);
                                if (windowProcessId == processId)
                                {
                                    StringBuilder className = new StringBuilder(256);
                                    GetClassName(windowHandle, className, className.Capacity);
                                    if (className.ToString().Contains("PPTFrameClass"))
                                    {
                                        pptHwnd = windowHandle;
                                        return false;
                                    }
                                }
                                return true;
                            }, IntPtr.Zero);

                            if (pptHwnd == IntPtr.Zero)
                            {
                                Thread.Sleep(500);
                                retryCount++;
                            }
                        }
                    }

                    if (pptHwnd != IntPtr.Zero)
                    {
                        GetWindowRect(pptHwnd, out RECT pptWindowRect);
                        GetClientRect(pptHwnd, out RECT pptClientRect);

                        int pptBorderWidth = (pptWindowRect.right - pptWindowRect.left) - pptClientRect.right;
                        int pptBorderHeight = (pptWindowRect.bottom - pptWindowRect.top) - pptClientRect.bottom;

                        int pptX = -pptBorderWidth / 2;
                        int pptY = -pptBorderHeight / 2;
                        int pptWidth = 1920 + pptBorderWidth;
                        int pptHeight = 774 + pptBorderHeight;

                        MoveWindow(pptHwnd, pptX, pptY, pptWidth, pptHeight, true);
                        System.Diagnostics.Debug.WriteLine($"[AppBarWindow] PowerPoint window positioned: {pptWidth}x{pptHeight} at ({pptX}, {pptY})");
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine("[AppBarWindow] PowerPoint window handle not found");
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[AppBarWindow] Error positioning PowerPoint window: {ex.Message}");
                }
            });
        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            // ウィンドウハンドルが利用可能になるまで少し待機してから配置
            Dispatcher.BeginInvoke(new Action(() =>
            {
                SetWindowPosition();
            }), DispatcherPriority.Loaded);
        }
        
        private void InitializeTimer()
        {
            // 50分（3000秒）からカウントダウン開始
            _remainingTime = TimeSpan.FromMinutes(50);
            UpdateTimerDisplay();
            
            // タイマーを1秒間隔で更新
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += Timer_Tick;
            
            // MainWindowのタイマー設定を確認
            bool timerDisabled = MainWindow.IsTimerDisabled;
            
            System.Diagnostics.Debug.WriteLine($"UiTestAppBarWindow: InitializeTimer called, IsTimerDisabled = {timerDisabled}");
            
            if (timerDisabled)
            {
                // タイマーは開始しない
                _timer.Stop();
                System.Diagnostics.Debug.WriteLine("UiTestAppBarWindow: Timer disabled, not starting");
                
                // 一時停止ボタンを無効化
                UpdatePauseButtonState(true);
            }
            else
            {
                _timer.Start();
                System.Diagnostics.Debug.WriteLine("UiTestAppBarWindow: Timer enabled, starting");
                
                // 一時停止ボタンを有効化
                UpdatePauseButtonState(false);
            }
        }
        
        private void UpdatePauseButtonState(bool isDisabled)
        {
            var pauseButton = FindName("PauseButton") as System.Windows.Controls.Button;
            if (pauseButton != null)
            {
                pauseButton.IsEnabled = !isDisabled;
            }
        }
        
        private void InitializeProjectTimer()
        {
            // プロジェクト用タイマーを初期化（5分制限）
            _projectTimer = new DispatcherTimer();
            _projectTimer.Interval = TimeSpan.FromSeconds(1);
            _projectTimer.Tick += ProjectTimer_Tick;
            
            // 最初のプロジェクト開始時刻を設定
            _projectStartTime = DateTime.Now;
            
            // MainWindowのタイマー設定を確認
            bool timerDisabled = MainWindow.IsTimerDisabled;
            
            if (!timerDisabled)
            {
                _projectTimer.Start();
            }
        }

        private void InitializeSlideMonitor()
        {
            PowerPointChecker1_1.ResetTask4SlideDeletionState();
            _slideMonitorTimer = new DispatcherTimer();
            _slideMonitorTimer.Interval = TimeSpan.FromSeconds(1);
            _slideMonitorTimer.Tick += SlideMonitor_Tick;
            _slideMonitorTimer.Start();
        }

        private void SlideMonitor_Tick(object sender, EventArgs e)
        {
            PowerPointApp pptApp = null;
            try
            {
                pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
            }
            catch (COMException)
            {
                return;
            }
            if (pptApp == null) return;
            PowerPointPresentation pres = null;
            try
            {
                pres = pptApp.ActivePresentation;
            }
            catch
            {
                return;
            }
            if (pres == null) return;
            Slides slides = null;
            try
            {
                slides = pres.Slides;
                if (slides == null) return;
                int count = slides.Count;
                var currentSlideIds = new List<int>();
                for (int i = 1; i <= count; i++)
                {
                    Slide slide = null;
                    try
                    {
                        slide = slides[i];
                        currentSlideIds.Add(slide.SlideID);
                    }
                    catch (COMException)
                    {
                        // スライド削除などでオブジェクトが無効になった場合はスキップ（強制終了を防ぐ）
                    }
                    finally
                    {
                        if (slide != null) { try { Marshal.ReleaseComObject(slide); } catch { } }
                    }
                }
                string presName = "";
                try { presName = pres.Name ?? ""; } catch { }
                string presKey = presName;
                try
                {
                    // 保存済みなら FullName がより一意で安定（無い場合は Name にフォールバック）
                    presKey = string.IsNullOrEmpty(pres.FullName) ? presName : pres.FullName;
                }
                catch { }
                PowerPointChecker1_1.CheckSlideDeletion(currentSlideIds, presKey);
            }
            finally
            {
                if (slides != null) { try { Marshal.ReleaseComObject(slides); } catch { } }
                if (pres != null) { try { Marshal.ReleaseComObject(pres); } catch { } }
                if (pptApp != null) { try { Marshal.ReleaseComObject(pptApp); } catch { } }
            }
        }
        
        private void Timer_Tick(object sender, EventArgs e)
        {
            // タイマーが無効化されている場合は何もしない
            if (MainWindow.IsTimerDisabled)
            {
                return;
            }
            
            if (_remainingTime.TotalSeconds > 0)
            {
                _remainingTime = _remainingTime.Subtract(TimeSpan.FromSeconds(1));
                UpdateTimerDisplay();
            }
            else
            {
                _timer.Stop();
                UpdateTimerDisplay();
                // 試験終了処理：結果画面を表示
                ShowResultWindowAsync();
            }
        }
        
        /// <summary>
        /// レビューページ（問題一覧）を表示する
        /// </summary>
        private void ShowReviewPageWindow()
        {
            try
            {
                var reviewWindow = new ReviewPageWindow(
                    _remainingTime,
                    _projectTaskCompletedStates,
                    _projectTaskFlaggedStates,
                    _projectTaskViewedStates,
                    _groupId);

                reviewWindow.OnNavigateToTask = (projectId, taskId) =>
                {
                    var appBar = System.Windows.Application.Current.Windows.OfType<UiTestAppBarWindow>().FirstOrDefault();
                    if (appBar != null)
                    {
                        appBar.Show();
                        appBar.Activate();
                        appBar.NavigateToTask(projectId, taskId);
                    }
                };
                reviewWindow.OnShowResultRequested = () =>
                {
                    ShowResultWindowAsync();
                };
                reviewWindow.OnBackRequested = () =>
                {
                    this.Show();
                    this.Activate();
                };

                reviewWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                reviewWindow.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[UiTestAppBarWindow] ShowReviewPageWindow error: {ex.Message}");
                MessageBox.Show($"レビューページの表示中にエラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// 結果画面を表示する（方式A: 表示前に全プロジェクトを採点してから結果を渡す）
        /// </summary>
        private async void ShowResultWindowAsync()
        {
            Window overlay = null;
            DispatcherTimer overlayKeepOnTopTimer = null;
            try
            {
                System.Diagnostics.Debug.WriteLine("[UiTestAppBarWindow] Showing result window (scoring all projects first)");

                // 採点中に UI タイマーが MoveToNextProject / OpenProjectDocument を走らせて COM と競合しないよう停止する
                _timer?.Stop();
                _projectTimer?.Stop();
                _slideMonitorTimer?.Stop();
                
                // 「採点中です」オーバーレイを表示
                // 待機を徹底するため画面中央に表示（Owner は付けず、ワークエリア中央 = CenterScreen）
                overlay = new Window
                {
                    Title = "採点中",
                    Width = 320,
                    Height = 140,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen,
                    WindowStyle = WindowStyle.ToolWindow,
                    ResizeMode = ResizeMode.NoResize,
                    ShowInTaskbar = false,
                    Topmost = true,
                    Content = new StackPanel
                    {
                        Margin = new Thickness(16, 14, 16, 14),
                        VerticalAlignment = VerticalAlignment.Center,
                        Children =
                        {
                            new TextBlock
                            {
                                Text = "採点中です。しばらくお待ちください...",
                                FontSize = 14,
                                TextAlignment = TextAlignment.Center,
                                HorizontalAlignment = HorizontalAlignment.Stretch,
                                Margin = new Thickness(0, 0, 0, 12)
                            },
                            new ProgressBar
                            {
                                Height = 14,
                                IsIndeterminate = true,
                                Minimum = 0,
                                Maximum = 100
                            }
                        }
                    }
                };
                overlay.Show();
                overlay.Activate();

                // PowerPoint 側が前面化しても、採点中表示が背面に回らないように保護する。
                overlayKeepOnTopTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
                overlayKeepOnTopTimer.Tick += (_, __) =>
                {
                    if (overlay == null || !overlay.IsVisible) return;
                    if (!overlay.IsActive)
                    {
                        overlay.Topmost = false;
                        overlay.Topmost = true;
                        overlay.Activate();
                    }
                };
                overlayKeepOnTopTimer.Start();
                await Task.Yield();
                
                // 全プロジェクトを採点（バックグラウンドで実行）
                Dictionary<int, List<bool>> allResults = null;
                await Task.Run(() =>
                {
                    try
                    {
                        allResults = ScoreAllProjects();
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"[ScoreAllProjects] Error: {ex.Message}");
                    }
                });
                
                if (overlay != null)
                {
                    overlayKeepOnTopTimer?.Stop();
                    try { overlay.Close(); } catch { }
                    overlay = null;
                }
                
                if (allResults == null)
                    allResults = new Dictionary<int, List<bool>>();
                
                // 結果画面を作成（採点結果を渡す）
                var resultWindow = new ResultWindow(_projectTaskCompletedStates, _projectTaskFlaggedStates, _projectTaskViewedStates, _groupId, allResults);
                resultWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                resultWindow.Topmost = true;
                
                resultWindow.OnEndRequested = () =>
                {
                    CloseAllPowerPointPresentations();
                    try
                    {
                        var pptProcesses = Process.GetProcessesByName("POWERPNT");
                        foreach (var proc in pptProcesses)
                        {
                            proc.Kill();
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"[OnEndRequested] PowerPoint プロセス終了エラー: {ex.Message}");
                    }
                    this.Close();
                    var main = System.Windows.Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                    if (main != null)
                    {
                        main.Show();
                        main.Activate();
                    }
                };
                
                resultWindow.OnNavigateToTask = (projectId, taskId) =>
                {
                    var appBarWindow = System.Windows.Application.Current.Windows.OfType<UiTestAppBarWindow>().FirstOrDefault();
                    if (appBarWindow != null)
                    {
                        appBarWindow.Show();
                        appBarWindow.Activate();
                        appBarWindow.NavigateToTask(projectId, taskId);
                    }
                };
                
                resultWindow.Show();
                resultWindow.Activate();
                this.Hide();
            }
            catch (Exception ex)
            {
                if (overlay != null)
                {
                    overlayKeepOnTopTimer?.Stop();
                    try { overlay.Close(); } catch { }
                }
                System.Diagnostics.Debug.WriteLine($"[UiTestAppBarWindow] Error showing result window: {ex.Message}");
                MessageBox.Show($"結果画面の表示中にエラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>プレゼンを開き直す処理が 300ms 以上かかる場合のみ「準備中」オーバーレイを表示する（速い遷移ではチラつきを抑える）。</summary>
        private const int PrepareProjectOverlayDelayMs = 300;

        private static Window CreatePrepareProjectOverlayWindow()
        {
            return new Window
            {
                Title = "プロジェクト準備中",
                SizeToContent = SizeToContent.WidthAndHeight,
                MinWidth = 260,
                MaxWidth = 420,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                WindowStyle = WindowStyle.ToolWindow,
                ResizeMode = ResizeMode.NoResize,
                ShowInTaskbar = false,
                Topmost = true,
                Content = new StackPanel
                {
                    Margin = new Thickness(16, 14, 16, 14),
                    MaxWidth = 388,
                    VerticalAlignment = VerticalAlignment.Center,
                    Children =
                    {
                        new TextBlock
                        {
                            Text = "プロジェクトを開いています。\nしばらくお待ちください...",
                            FontSize = 14,
                            TextWrapping = TextWrapping.Wrap,
                            TextAlignment = TextAlignment.Center,
                            HorizontalAlignment = HorizontalAlignment.Stretch,
                            MaxWidth = 356
                        }
                    }
                }
            };
        }

        private static DispatcherTimer StartPrepareOverlayKeepOnTopTimer(Window overlay)
        {
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
            timer.Tick += (_, __) =>
            {
                if (overlay == null || !overlay.IsVisible) return;
                if (!overlay.IsActive)
                {
                    overlay.Topmost = false;
                    overlay.Topmost = true;
                    overlay.Activate();
                }
            };
            timer.Start();
            return timer;
        }

        /// <summary>
        /// 遅延後に準備中オーバーレイを表示しつつ遷移処理を実行する。
        /// 処理の合間で Dispatcher を yield し、オーバーレイの表示キューが処理されるようにする。
        /// </summary>
        private async Task RunWithDelayedPrepareOverlayAsync(Func<Task> transitionAsync)
        {
            bool transitionCompleted = false;
            Window overlay = null;
            DispatcherTimer overlayKeepOnTopTimer = null;
            System.Threading.Timer showOverlayTimer = null;

            void ShowOverlayIfNeeded()
            {
                if (transitionCompleted) return;
                if (overlay != null) return;
                try
                {
                    overlay = CreatePrepareProjectOverlayWindow();
                    overlay.Show();
                    overlay.Activate();
                    overlayKeepOnTopTimer = StartPrepareOverlayKeepOnTopTimer(overlay);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[RunWithDelayedPrepareOverlay] Show overlay: {ex.Message}");
                }
            }

            showOverlayTimer = new System.Threading.Timer(
                _ => Dispatcher.BeginInvoke(new Action(ShowOverlayIfNeeded)),
                null,
                PrepareProjectOverlayDelayMs,
                Timeout.Infinite);

            try
            {
                await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
                await transitionAsync();
            }
            finally
            {
                transitionCompleted = true;
                showOverlayTimer?.Dispose();
                showOverlayTimer = null;
                overlayKeepOnTopTimer?.Stop();
                overlayKeepOnTopTimer = null;
                if (overlay != null)
                {
                    try { overlay.Close(); } catch { }
                    overlay = null;
                }
            }
        }
        
        /// <summary>
        /// 全プロジェクトを採点し、projectId → タスクごとの正否リスト を返す（方式A用）
        /// </summary>
        private Dictionary<int, List<bool>> ScoreAllProjects()
        {
            var results = new Dictionary<int, List<bool>>();
            if (_projectData?.Projects == null || _projectData.Projects.Count == 0)
                return results;
            
            PowerPointGrader grader = null;
            try
            {
                grader = new PowerPointGrader();
                foreach (var project in _projectData.Projects.OrderBy(p => p.ProjectId))
                {
                    if (project.Tasks == null || project.Tasks.Count == 0)
                        continue;
                    var list = new List<bool>();
                    try
                    {
                        OpenProjectDocument(project.ProjectId, _groupId);
                        Thread.Sleep(800);
                        // OpenProjectDocument は CloseAll 後に別ファイルを開くため、採点前に ActivePresentation を必ず取り直す
                        if (!grader.Connect())
                        {
                            System.Diagnostics.Debug.WriteLine($"[ScoreAllProjects] PowerPoint に接続できないかプレゼンがありません (Project {project.ProjectId})");
                            for (int i = 0; i < project.Tasks.Count; i++)
                                list.Add(false);
                            results[project.ProjectId] = list;
                            continue;
                        }
                        foreach (var task in project.Tasks.OrderBy(t => t.TaskId))
                        {
                            bool passed = false;
                            try
                            {
                                // スナップショット ID Mismatch を防ぐため、採点前に current_task を更新し、
                                // VSTO 側の snapshot 更新を短時間待ってから GradeTask を呼ぶ。
                                int attemptNo = Libraries.PPTaskAttemptRegistry.GetAttempt(project.ProjectId, task.TaskId);
                                grader.StartTaskAndWaitForSnapshot(project.ProjectId, task.TaskId, attemptNo, 2000, 50);
                                passed = grader.GradeTask(project.ProjectId, task.TaskId, attemptNo);
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine($"[ScoreAllProjects] GradeTask {project.ProjectId}-{task.TaskId}: {ex.Message}");
                            }
                            list.Add(passed);
                        }
                        results[project.ProjectId] = list;
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"[ScoreAllProjects] Project {project.ProjectId}: {ex.Message}");
                        for (int i = 0; i < project.Tasks.Count; i++)
                            list.Add(false);
                        if (list.Count > 0)
                            results[project.ProjectId] = list;
                    }
                }
            }
            finally
            {
                try { grader?.Dispose(); } catch { }
            }
            System.Diagnostics.Debug.WriteLine($"[ScoreAllProjects] Done: {results.Count} projects");
            return results;
        }
        
        /// <summary>
        /// タスクに移動する（結果画面から呼び出される）
        /// </summary>
        public async void NavigateToTask(int projectId, int taskId)
        {
            System.Diagnostics.Debug.WriteLine($"NavigateToTask called: ProjectId={projectId}, TaskId={taskId}");

            try
            {
                // プロジェクト切り替えやジャンプ前に一旦タスク情報をクリアし、アドイン側の誤検知を防ぐ
                Libraries.PPLogReader.ClearCurrentTaskFile();

                await RunWithDelayedPrepareOverlayAsync(async () =>
                {
                    // レビューページから戻ったときは常に該当プロジェクトのプレゼンテーションを開く
                    await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
                    OpenProjectDocument(projectId, _groupId);
                    await Dispatcher.Yield(DispatcherPriority.Background);

                    // プロジェクトを変更
                    if (projectId != _currentProjectId)
                    {
                        System.Diagnostics.Debug.WriteLine($"プロジェクト変更: {_currentProjectId} -> {projectId}");
                        _currentProjectId = projectId;
                        LoadCurrentProjectTasks();
                    }

                    // タスクを変更
                    if (taskId != _currentTaskId && taskId >= 1 && taskId <= _tasks.Count)
                    {
                        System.Diagnostics.Debug.WriteLine($"タスク変更: {_currentTaskId} -> {taskId}");
                        _currentTaskId = taskId;
                    }

                    // UIを更新
                    UpdateTaskDisplay();
                    WriteCurrentTaskFile();

                    // メインウィンドウを表示
                    this.Show();
                    this.WindowState = WindowState.Normal;
                    this.Activate();
                    this.Focus();

                    System.Diagnostics.Debug.WriteLine($"プロジェクト{projectId}のタスク{taskId}に移動しました");
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"ナビゲーションエラー: {ex.Message}");
            }
        }
        
        /// <summary>
        /// 採点結果を結果画面用の解答済み状態に反映する（方式B: 採点で合格したタスクを〇で表示するため）
        /// </summary>
        /// <param name="projectId">対象プロジェクトID</param>
        /// <param name="taskResults">採点結果（TaskNumber は 1 始まり、IsPassed で合格/不合格）</param>
        public void ApplyScoreResults(int projectId, IEnumerable<MOS_PowerPoint_app.TaskResult> taskResults)
        {
            if (taskResults == null) return;
            var list = taskResults.ToList();
            if (list.Count == 0) return;
            int arraySize = list.Max(t => t.TaskNumber);
            if (arraySize < 1) return;
            if (!_projectTaskCompletedStates.ContainsKey(projectId) || _projectTaskCompletedStates[projectId].Length < arraySize)
            {
                var newArray = new bool[arraySize];
                if (_projectTaskCompletedStates.ContainsKey(projectId))
                {
                    var old = _projectTaskCompletedStates[projectId];
                    Array.Copy(old, newArray, Math.Min(old.Length, arraySize));
                }
                _projectTaskCompletedStates[projectId] = newArray;
            }
            bool[] completedStates = _projectTaskCompletedStates[projectId];
            foreach (var task in list)
            {
                int index = task.TaskNumber - 1;
                if (index >= 0 && index < completedStates.Length)
                {
                    completedStates[index] = task.IsPassed;
                }
            }
            System.Diagnostics.Debug.WriteLine($"[ApplyScoreResults] プロジェクト{projectId}: {list.Count(r => r.IsPassed)}/{list.Count} を解答済みに反映しました");
        }
        
        private void ProjectTimer_Tick(object sender, EventArgs e)
        {
            // タイマーが無効化されている場合は何もしない
            if (MainWindow.IsTimerDisabled)
            {
                return;
            }
            
            // プロジェクト開始から5分経過したかチェック
            var elapsed = DateTime.Now - _projectStartTime;
            if (elapsed.TotalMinutes >= 5.0)
            {
                _projectTimer.Stop();
                MoveToNextProjectWithMessage();
            }
        }
        
        private void UpdateTimerDisplay()
        {
            // タイマーの表示を更新
            var timerTextBlock = FindName("TimerTextBlock") as System.Windows.Controls.TextBlock;
            if (timerTextBlock != null)
            {
                timerTextBlock.Text = _remainingTime.ToString(@"hh\:mm\:ss");
            }
        }
        
        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // タイマーが無効化されている場合は何もしない
                if (MainWindow.IsTimerDisabled)
                {
                    MessageBox.Show("タイマーは無効化されています。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                
                if (!_isPaused)
                {
                    // 一時停止
                    _timer?.Stop();
                    _projectTimer?.Stop();
                    _pauseStartTime = DateTime.Now;
                    _isPaused = true;
                    
                    // ボタンテキストを「再開」に変更
                    var pauseButton = sender as System.Windows.Controls.Button;
                    if (pauseButton != null)
                    {
                        pauseButton.Content = "再開";
                    }
                    
                    System.Diagnostics.Debug.WriteLine("[PauseButton] 一時停止しました");
                }
                else
                {
                    // 再開
                    // 一時停止時間を計算
                    var pauseDuration = DateTime.Now - _pauseStartTime;
                    
                    // プロジェクト開始時刻を調整（一時停止時間分を加算）
                    _projectStartTime = _projectStartTime.Add(pauseDuration);
                    
                    // タイマーを再開
                    _timer?.Start();
                    _projectTimer?.Start();
                    _isPaused = false;
                    
                    // ボタンテキストを「一時停止」に変更
                    var pauseButton = sender as System.Windows.Controls.Button;
                    if (pauseButton != null)
                    {
                        pauseButton.Content = "一時停止";
                    }
                    
                    System.Diagnostics.Debug.WriteLine($"[PauseButton] 再開しました（一時停止時間: {pauseDuration.TotalSeconds}秒）");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[PauseButton] Error: {ex.Message}");
                MessageBox.Show($"一時停止/再開処理中にエラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void ScoreButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SyncProjectToMainViewModel();
                System.Diagnostics.Debug.WriteLine($"[ScoreButton] 採点を開始: プロジェクト{_currentProjectId}, グループ{_groupId} (PowerPoint)");
                
                // プロジェクト一覧画面の採点と同じ処理を実行（MainViewModel.ExecuteScore → 採点結果ダイアログ表示）
                if (_onScoreClick != null)
                    _onScoreClick();
                else
                    MessageBox.Show("採点機能は利用できません。プロジェクト一覧からプロジェクトを開いて採点してください。", "採点", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[ScoreButton] Error: {ex.Message}");
                MessageBox.Show($"採点中にエラーが発生しました:\n{ex.Message}", "採点エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        /// <summary>
        /// 閉じるボタン（Excelに合わせて結果画面は表示せず、試験終了してメインに戻る）
        /// </summary>
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("アプリ自体を終了します。本当にいいですか？", "確認", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
                return;
            _timer?.Stop();
            _projectTimer?.Stop();
            SaveAllPowerPointPresentations();
            CloseAllPowerPointPresentations();
            try
            {
                var pptProcesses = Process.GetProcessesByName("POWERPNT");
                foreach (var proc in pptProcesses)
                {
                    proc.Kill();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[CloseButton] PowerPoint プロセス終了エラー: {ex.Message}");
            }
            this.Close();
            var main = System.Windows.Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
            if (main != null)
            {
                main.Show();
                main.Activate();
            }
        }
        
        private void ReviewPageButton_Click(object sender, RoutedEventArgs e)
        {
            ShowReviewPageWindow();
        }

        /// <summary>
        /// 結果画面から来たフラグを設定し、ボタン表示を切り替える
        /// </summary>
        public void SetFromResultWindow(bool fromResultWindow)
        {
            _fromResultWindow = fromResultWindow;
            UpdateReviewPageButtonVisibility();
        }

        /// <summary>
        /// 結果画面への参照を保持する
        /// </summary>
        public void SetResultWindow(ResultWindow resultWindow)
        {
            _resultWindow = resultWindow;
        }

        public void SetInitialWrongTaskKeys(IEnumerable<string> keys)
        {
            _initialWrongTaskKeys.Clear();
            if (keys == null) return;
            foreach (var key in keys)
            {
                if (!string.IsNullOrWhiteSpace(key))
                    _initialWrongTaskKeys.Add(key);
            }
        }

        public bool TryPrepareRetryAttemptFromResult(int projectId, int taskId)
        {
            string key = GetTaskKey(projectId, taskId);
            if (!_initialWrongTaskKeys.Contains(key))
                return false;
            return EnsureRetryAttemptPrepared(projectId, taskId);
        }

        private void UpdateReviewPageButtonVisibility()
        {
            var reviewPageButton = FindName("ReviewPageButton") as System.Windows.Controls.Button;
            var returnToResultButton = FindName("ReturnToResultButton") as System.Windows.Controls.Button;

            if (reviewPageButton != null && returnToResultButton != null)
            {
                if (_fromResultWindow)
                {
                    reviewPageButton.Visibility = Visibility.Collapsed;
                    returnToResultButton.Visibility = Visibility.Visible;
                }
                else
                {
                    reviewPageButton.Visibility = Visibility.Visible;
                    returnToResultButton.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void ReturnToResultButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_fromResultWindow)
                {
                    TryRescorePendingRetryTasks();
                }

                // 結果画面を表示
                if (_resultWindow != null && !_resultWindow.IsVisible)
                {
                    _resultWindow.Show();
                    _resultWindow.Activate();
                    _resultWindow.Focus();
                }
                else
                {
                    // 既存の結果画面を探す
                    var resultWindow = System.Windows.Application.Current.Windows.OfType<ResultWindow>().FirstOrDefault();
                    if (resultWindow != null)
                    {
                        resultWindow.Show();
                        resultWindow.Activate();
                        resultWindow.Focus();
                    }
                }

                // AppBarWindowを非表示にする
                this.Hide();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[ReturnToResultButton] Error: {ex.Message}");
                MessageBox.Show("結果画面の表示に失敗しました。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        
        
        private void LoadTasks()
        {
            try
            {
                // JSONファイルから問題文を読み込む（プロジェクトルートのファイルを使用）
                string jsonPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MOS模擬アプリ問題文一覧_PowerPoint.json");
                
                // ファイルが存在しない場合は、References/JSONフォルダも試す
                if (!File.Exists(jsonPath))
                {
                    jsonPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "References", "JSON", "MOS模擬アプリ問題文一覧_PowerPoint.json");
                }
                
                // ファイルが存在しない場合はエラー
                if (!File.Exists(jsonPath))
                {
                    System.Diagnostics.Debug.WriteLine($"JSONファイルが見つかりません: {jsonPath}");
                    _tasks = new List<TaskInfo>();
                    return;
                }
                
                // JSONファイルを読み込む
                LoadTasksFromJson(jsonPath);
                
                // 現在のプロジェクトのタスクを取得
                LoadCurrentProjectTasks();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"タスク読み込みエラー: {ex.Message}");
                _tasks = new List<TaskInfo>();
            }
        }
        
        private void LoadTasksFromJson(string jsonPath)
        {
            try
            {
                string jsonContent = File.ReadAllText(jsonPath, Encoding.UTF8);
                _projectData = JsonConvert.DeserializeObject<ProjectData>(jsonContent);
                
                System.Diagnostics.Debug.WriteLine($"JSONから{_projectData?.Projects?.Count ?? 0}個のプロジェクト、合計{_projectData?.Projects?.Sum(p => p.Tasks?.Count ?? 0) ?? 0}個のタスクを読み込みました");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"JSON読み込みエラー: {ex.Message}");
                _projectData = new ProjectData { Projects = new List<ProjectInfo>() };
            }
        }
        
        private void LoadClipboardTargets()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("[LoadClipboardTargets] 開始");
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] AppDomain.CurrentDomain.BaseDirectory: {AppDomain.CurrentDomain.BaseDirectory}");
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] Assembly.Location: {System.Reflection.Assembly.GetExecutingAssembly().Location}");
                
                // コピー対象問題JSON（入力・追加・変更・挿入の問題）を優先して読み込む
                string copyTargetJsonName = "MOS模擬アプリ_入力追加変更挿入問題_PowerPoint.json";
                string jsonPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, copyTargetJsonName);
                if (!File.Exists(jsonPath))
                    jsonPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "References", "JSON", copyTargetJsonName);
                if (File.Exists(jsonPath))
                {
                    try
                    {
                        string jsonContent = File.ReadAllText(jsonPath, Encoding.UTF8);
                        var copyTargetData = JsonConvert.DeserializeObject<ProjectData>(jsonContent);
                        if (copyTargetData?.Projects != null)
                        {
                            _clipboardTargets.Clear();
                            foreach (var project in copyTargetData.Projects)
                            {
                                if (project.Tasks == null) continue;
                                _clipboardTargets[project.ProjectId] = new Dictionary<int, string>();
                                foreach (var task in project.Tasks)
                                {
                                    if (!string.IsNullOrEmpty(task.Description))
                                        _clipboardTargets[project.ProjectId][task.TaskId] = task.Description;
                                }
                            }
                            System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] JSONからクリップボード対象を{_clipboardTargets.Sum(p => p.Value.Count)}件読み込みました: {jsonPath}");
                            return;
                        }
                    }
                    catch (Exception exJson)
                    {
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] JSON読み込み失敗、CSVにフォールバック: {exJson.Message}");
                    }
                }
                
                // CSVファイル名（JSONが無い場合のフォールバック）
                string csvFileName = "MOS模擬アプリ正誤判定表251120_挿入入力のみ.csv";
                
                // 複数のパス候補を試す
                List<string> pathCandidates = new List<string>();
                
                // 1. 実行ディレクトリからの相対パス
                pathCandidates.Add(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Reference", "CSV", csvFileName));
                
                // 2. 実行ディレクトリからの相対パス（References）
                pathCandidates.Add(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "References", "CSV", csvFileName));
                
                // 3. アセンブリの場所からの相対パス
                string assemblyLocation = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string assemblyDir = Path.GetDirectoryName(assemblyLocation);
                pathCandidates.Add(Path.Combine(assemblyDir, "Reference", "CSV", csvFileName));
                pathCandidates.Add(Path.Combine(assemblyDir, "References", "CSV", csvFileName));
                
                // 4. プロジェクトルートからの相対パス
                string projectRoot = Path.GetDirectoryName(assemblyDir);
                if (projectRoot != null)
                {
                    pathCandidates.Add(Path.Combine(projectRoot, "Reference", "CSV", csvFileName));
                    pathCandidates.Add(Path.Combine(projectRoot, "References", "CSV", csvFileName));
                }
                
                // 5. さらに上の階層も試す
                if (projectRoot != null)
                {
                    string projectRootParent = Path.GetDirectoryName(projectRoot);
                    if (projectRootParent != null)
                    {
                        pathCandidates.Add(Path.Combine(projectRootParent, "Reference", "CSV", csvFileName));
                        pathCandidates.Add(Path.Combine(projectRootParent, "References", "CSV", csvFileName));
                    }
                }
                
                string csvPath = null;
                foreach (string candidatePath in pathCandidates)
                {
                    System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] パス候補を確認: {candidatePath}");
                    if (File.Exists(candidatePath))
                    {
                        csvPath = candidatePath;
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] CSVファイルが見つかりました: {csvPath}");
                        break;
                    }
                }
                
                if (csvPath == null)
                {
                    System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] クリップボード対象CSVファイルが見つかりません。試したパス:");
                    foreach (string candidatePath in pathCandidates)
                    {
                        System.Diagnostics.Debug.WriteLine($"  - {candidatePath}");
                    }
                    return;
                }
                
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] CSVファイルを読み込みます: {csvPath}");
                string[] lines = File.ReadAllLines(csvPath, Encoding.UTF8);
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] CSVファイルの行数: {lines.Length}");
                
                int loadedCount = 0;
                // ヘッダー行をスキップ（1行目）
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (string.IsNullOrEmpty(line))
                        continue;
                    
                    // デバッグ: 元の行の内容を確認
                    System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] 行 {i + 1} の元の内容: {line}");
                    
                    // CSVのパース（カンマ区切り、引用符内のカンマを考慮）
                    string[] fields = ParseCsvLine(line);
                    System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] 行 {i + 1} のパース結果: {fields.Length}個のフィールド");
                    for (int j = 0; j < fields.Length; j++)
                    {
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets]   フィールド{j}: {fields[j].Substring(0, Math.Min(100, fields[j].Length))}...");
                    }
                    
                    if (fields.Length < 3)
                    {
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] フィールド数が不足: {fields.Length} (行 {i + 1})");
                        continue;
                    }
                    
                    // プロジェクト,タスク,問題文,解答操作
                    if (int.TryParse(fields[0].Trim(), out int projectId) &&
                        int.TryParse(fields[1].Trim(), out int taskId))
                    {
                        string description = fields.Length > 2 ? fields[2].Trim() : "";
                        if (string.IsNullOrEmpty(description))
                            continue;
                        
                        // デバッグ: 問題文に""が含まれているか確認
                        bool containsQuotes = description.Contains('"');
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] 問題文に\"が含まれているか: {containsQuotes}");
                        if (containsQuotes)
                        {
                            int quoteCount = description.Count(c => c == '"');
                            System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] 問題文内の\"の数: {quoteCount}");
                        }
                        
                        // プロジェクトが存在しない場合は作成
                        if (!_clipboardTargets.ContainsKey(projectId))
                        {
                            _clipboardTargets[projectId] = new Dictionary<int, string>();
                        }
                        
                        // 問題文を保存（「"」で囲まれた部分を含む）
                        _clipboardTargets[projectId][taskId] = description;
                        loadedCount++;
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] 読み込み: プロジェクト{projectId}, タスク{taskId}, 問題文: {description.Substring(0, Math.Min(50, description.Length))}...");
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] プロジェクトIDまたはタスクIDのパースに失敗 (行 {i + 1}): {fields[0]}, {fields[1]}");
                    }
                }
                
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] クリップボード対象を{_clipboardTargets.Sum(p => p.Value.Count)}件読み込みました (実際の読み込み数: {loadedCount})");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] クリップボード対象読み込みエラー: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"[LoadClipboardTargets] スタックトレース: {ex.StackTrace}");
            }
        }
        
        private void LoadTasksFromCsv(string csvPath)
        {
            try
            {
                // MOSボタンアプリ正誤判定表.csvは「タスク,問題文,解答操作」形式
                // プロジェクト情報がないため、全タスクをプロジェクト1に割り当て
                var tasks = new List<TaskInfo>();
                
                string[] lines = File.ReadAllLines(csvPath, Encoding.UTF8);
                
                // ヘッダー行をスキップ（1行目）
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (string.IsNullOrEmpty(line))
                        continue;
                    
                    // CSVのパース（カンマ区切り、引用符内のカンマを考慮）
                    string[] fields = ParseCsvLine(line);
                    if (fields.Length < 2)
                        continue;
                    
                    // タスク,問題文,解答操作
                    if (int.TryParse(fields[0].Trim(), out int taskId))
                    {
                        string description = fields.Length > 1 ? fields[1].Trim() : "";
                        if (string.IsNullOrEmpty(description))
                            continue;
                        
                        tasks.Add(new TaskInfo
                        {
                            TaskId = taskId,
                            Description = description
                        });
                    }
                }
                
                // タスクをタスクID順にソート
                tasks.Sort((a, b) => a.TaskId.CompareTo(b.TaskId));
                
                // プロジェクト1として設定
                _projectData = new ProjectData
                {
                    Projects = new List<ProjectInfo>
                    {
                        new ProjectInfo
                        {
                            ProjectId = 1,
                            Tasks = tasks
                        }
                    }
                };
                
                System.Diagnostics.Debug.WriteLine($"CSVからプロジェクト1に{tasks.Count}個のタスクを読み込みました");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"CSV読み込みエラー: {ex.Message}");
                _projectData = new ProjectData { Projects = new List<ProjectInfo>() };
            }
        }
        
        private string[] ParseCsvLine(string line)
        {
            var fields = new List<string>();
            bool inQuotes = false;
            int fieldStartIndex = 0; // 現在のフィールドの開始位置
            StringBuilder currentField = new StringBuilder();
            
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                
                if (c == '"')
                {
                    if (!inQuotes)
                    {
                        // フィールドの開始引用符の可能性
                        // 次の文字を確認して、フィールド全体が引用符で囲まれているか判断
                        bool isFieldStart = (i == 0 || line[i - 1] == ',');
                        if (isFieldStart)
                        {
                            // フィールドの開始引用符
                            inQuotes = true;
                            fieldStartIndex = i;
                            // 開始引用符は追加しない（CSV標準）
                        }
                        else
                        {
                            // フィールド内の引用符（フィールド全体が引用符で囲まれていない場合）
                            // この場合は引用符を保持する
                            currentField.Append('"');
                        }
                    }
                    else if (i + 1 < line.Length && line[i + 1] == '"')
                    {
                        // エスケープされた引用符（""）
                        currentField.Append('"');
                        i++; // 次の文字をスキップ
                    }
                    else if (i + 1 < line.Length && (line[i + 1] == ',' || i + 1 == line.Length))
                    {
                        // フィールドの終了引用符（次の文字がカンマまたは行末）
                        inQuotes = false;
                        // 終了引用符は追加しない（CSV標準）
                    }
                    else
                    {
                        // フィールド内の引用符（フィールド全体が引用符で囲まれていない場合）
                        // この場合は引用符を保持する
                        currentField.Append('"');
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    // フィールドの区切り
                    fields.Add(currentField.ToString());
                    currentField.Clear();
                    fieldStartIndex = i + 1;
                }
                else
                {
                    currentField.Append(c);
                }
            }
            
            // 最後のフィールドを追加
            fields.Add(currentField.ToString());
            
            return fields.ToArray();
        }
        
        private void LoadCurrentProjectTasks()
        {
            if (_projectData != null)
            {
                var currentProject = _projectData.Projects.Find(p => p.ProjectId == _currentProjectId);
                if (currentProject != null)
                {
                    _tasks = currentProject.Tasks;
                    _currentTaskId = 1; // 新しいプロジェクトの最初のタスクにリセット
                    
                    // 新しいプロジェクトの状態を初期化（タスク数に合わせて動的にサイズを設定）
                    int taskCount = _tasks != null ? _tasks.Count : 0;
                    int arraySize = Math.Max(taskCount, 1); // タスク数、最小1（配列は0始まりなので+1は不要）
                    
                    if (!_projectTaskCompletedStates.ContainsKey(_currentProjectId))
                    {
                        _projectTaskCompletedStates[_currentProjectId] = new bool[arraySize];
                    }
                    else
                    {
                        // 既存の配列のサイズが不足している場合は拡張
                        if (_projectTaskCompletedStates[_currentProjectId].Length < arraySize)
                        {
                            var oldArray = _projectTaskCompletedStates[_currentProjectId];
                            var newArray = new bool[arraySize];
                            Array.Copy(oldArray, newArray, oldArray.Length);
                            _projectTaskCompletedStates[_currentProjectId] = newArray;
                        }
                    }
                    
                    if (!_projectTaskFlaggedStates.ContainsKey(_currentProjectId))
                    {
                        _projectTaskFlaggedStates[_currentProjectId] = new bool[arraySize];
                    }
                    else
                    {
                        // 既存の配列のサイズが不足している場合は拡張
                        if (_projectTaskFlaggedStates[_currentProjectId].Length < arraySize)
                        {
                            var oldArray = _projectTaskFlaggedStates[_currentProjectId];
                            var newArray = new bool[arraySize];
                            Array.Copy(oldArray, newArray, oldArray.Length);
                            _projectTaskFlaggedStates[_currentProjectId] = newArray;
                        }
                    }
                    
                    // 閲覧状態も初期化
                    if (!_projectTaskViewedStates.ContainsKey(_currentProjectId))
                    {
                        _projectTaskViewedStates[_currentProjectId] = new bool[arraySize];
                    }
                    else
                    {
                        // 既存の配列のサイズが不足している場合は拡張
                        if (_projectTaskViewedStates[_currentProjectId].Length < arraySize)
                        {
                            var oldArray = _projectTaskViewedStates[_currentProjectId];
                            var newArray = new bool[arraySize];
                            Array.Copy(oldArray, newArray, oldArray.Length);
                            _projectTaskViewedStates[_currentProjectId] = newArray;
                        }
                    }
                }
                else
                {
                    _tasks = new List<TaskInfo>();
                }
            }
            
            // プロジェクトタイトルを更新
            UpdateProjectTitle();
            WriteCurrentTaskFile();
            SyncProjectToMainViewModel();
        }
        
        private void UpdateProjectTitle()
        {
            if (_projectData?.Projects != null)
            {
                int totalProjects = _projectData.Projects.Count;
                var projectInfoTextBlock = FindName("ProjectInfoTextBlock") as System.Windows.Controls.TextBlock;
                if (projectInfoTextBlock != null)
                {
                    projectInfoTextBlock.Text = $"プロジェクト {_currentProjectId}/{totalProjects}";
                }
            }
        }
        
        private void UpdateTaskDisplay()
        {
            System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] 開始: プロジェクト{_currentProjectId}, タスク{_currentTaskId}");
            
            // 閲覧状態を記録（未読問題の追跡用）
            MarkTaskAsViewed(_currentProjectId, _currentTaskId);
            
            // タスク説明の表示を更新
            var taskDescriptionTextBlock = FindName("TaskDescriptionTextBlock") as System.Windows.Controls.TextBlock;
            if (taskDescriptionTextBlock == null)
            {
                System.Diagnostics.Debug.WriteLine("[UpdateTaskDisplay] TaskDescriptionTextBlockが見つかりません");
                return;
            }
            
            if (_tasks == null)
            {
                System.Diagnostics.Debug.WriteLine("[UpdateTaskDisplay] _tasksがnullです");
                return;
            }
            
            if (_currentTaskId > _tasks.Count)
            {
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] _currentTaskId({_currentTaskId})が_tasks.Count({_tasks.Count})を超えています");
                return;
            }
            
            var currentTask = _tasks.Find(t => t.TaskId == _currentTaskId);
            if (currentTask == null)
            {
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] タスク{_currentTaskId}が見つかりません");
                return;
            }
            
            System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] _clipboardTargetsにプロジェクト{_currentProjectId}が含まれているか: {_clipboardTargets.ContainsKey(_currentProjectId)}");
            if (_clipboardTargets.ContainsKey(_currentProjectId))
            {
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] プロジェクト{_currentProjectId}のタスク数: {_clipboardTargets[_currentProjectId].Count}");
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] プロジェクト{_currentProjectId}にタスク{_currentTaskId}が含まれているか: {_clipboardTargets[_currentProjectId].ContainsKey(_currentTaskId)}");
            }
            
            // 現在のプロジェクト・タスクがクリップボード対象に含まれているかチェック
            string clipboardTargetDescription = null;
            if (_clipboardTargets.ContainsKey(_currentProjectId) &&
                _clipboardTargets[_currentProjectId].ContainsKey(_currentTaskId))
            {
                clipboardTargetDescription = _clipboardTargets[_currentProjectId][_currentTaskId];
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] クリップボード対象の問題文を取得: {clipboardTargetDescription.Substring(0, Math.Min(100, clipboardTargetDescription.Length))}...");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] クリップボード対象が見つかりません。通常の問題文を使用します");
            }
            
            // コピーできる部分を""で囲んでから表示（「…」と入力 の 「」内をコピー対象に）
            string descriptionForDisplay = clipboardTargetDescription ?? currentTask.Description;
            descriptionForDisplay = WrapCopyablePartInQuotes(descriptionForDisplay);
            if (clipboardTargetDescription != null)
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] SetTextWithUnderlineを呼び出します（クリップボード対象）");
            else
                System.Diagnostics.Debug.WriteLine($"[UpdateTaskDisplay] SetTextWithUnderlineを呼び出します（通常の問題文）");
            SetTextWithUnderline(taskDescriptionTextBlock, descriptionForDisplay);
            
            // タスクボタンの状態を更新（チェックマークと旗マークも含む）
            UpdateTaskButtons();
            
            // ボタンのテキストを更新
            UpdateButtonTexts();
        }
        
        /// <summary>
        /// タスクを閲覧済みとして記録（未読問題の追跡用）
        /// </summary>
        private void MarkTaskAsViewed(int projectId, int taskId)
        {
            // 現在のプロジェクトの状態を取得または初期化
            if (!_projectTaskViewedStates.ContainsKey(projectId))
            {
                int taskCount = _tasks != null ? _tasks.Count : 0;
                int arraySize = Math.Max(taskCount, 1);
                _projectTaskViewedStates[projectId] = new bool[arraySize];
            }
            
            bool[] viewedStates = _projectTaskViewedStates[projectId];
            // タスクIDは1始まり、配列は0始まりなので -1
            int arrayIndex = taskId - 1;
            
            if (arrayIndex >= 0 && arrayIndex < viewedStates.Length)
            {
                viewedStates[arrayIndex] = true;
                System.Diagnostics.Debug.WriteLine($"[MarkTaskAsViewed] プロジェクト{projectId}のタスク{taskId}を閲覧済みとして記録しました");
            }
        }
        
        /// <summary>
        /// 問題文からコピーすべき部分（「…」と入力 の 「」内など）を抽出し、半角ダブルクォートで囲んだ文字列を返します。
        /// 既に"が含まれる問題文はそのまま返します。
        /// </summary>
        private static string WrapCopyablePartInQuotes(string description)
        {
            if (string.IsNullOrEmpty(description)) return description;
            if (description.IndexOf('"') >= 0) return description;
            // 「…」と入力 の 「」内を "…" に変換（コピーできる部分として表示）
            return Regex.Replace(description, @"「([^」]*)」と入力", "\"$1\"と入力");
        }

        /// <summary>
        /// テキスト内の"で囲まれた部分に下線を付けてTextBlockに設定します
        /// "自体は表示せず、その中のテキストだけに下線を付けます
        /// </summary>
        private void SetTextWithUnderline(TextBlock textBlock, string text)
        {
            System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] 開始: テキスト長={text?.Length ?? 0}");
            
            if (string.IsNullOrEmpty(text))
            {
                System.Diagnostics.Debug.WriteLine("[SetTextWithUnderline] テキストが空です");
                textBlock.Text = string.Empty;
                return;
            }

            System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] テキスト内容: {text.Substring(0, Math.Min(100, text.Length))}...");
            
            textBlock.Inlines.Clear();
            textBlock.Text = string.Empty; // TextプロパティをクリアしてInlinesを使用
            
            // "で囲まれた部分を検索して下線を付ける
            int startIndex = 0;
            bool foundQuotes = false;
            int quoteCount = 0;
            
            while (startIndex < text.Length)
            {
                // "の開始位置を検索（半角ダブルクォート）
                int quoteStart = text.IndexOf('"', startIndex);
                if (quoteStart == -1)
                {
                    // "が見つからない場合は残りのテキストをそのまま追加
                    if (startIndex < text.Length)
                    {
                        string remainingText = text.Substring(startIndex);
                        if (!string.IsNullOrEmpty(remainingText))
                        {
                            textBlock.Inlines.Add(new Run(remainingText));
                        }
                    }
                    break;
                }
                
                foundQuotes = true;
                quoteCount++;
                System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] \"を検出 (位置 {quoteStart}, {quoteCount}個目)");
                
                // "の前のテキストを追加
                if (quoteStart > startIndex)
                {
                    string beforeText = text.Substring(startIndex, quoteStart - startIndex);
                    textBlock.Inlines.Add(new Run(beforeText));
                    System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] \"の前のテキストを追加: {beforeText.Substring(0, Math.Min(50, beforeText.Length))}...");
                }
                
                // "の終了位置を検索
                int quoteEnd = text.IndexOf('"', quoteStart + 1);
                if (quoteEnd == -1)
                {
                    // "が見つからない場合は残りをそのまま追加
                    System.Diagnostics.Debug.WriteLine("[SetTextWithUnderline] 終了の\"が見つかりません");
                    textBlock.Inlines.Add(new Run(text.Substring(quoteStart)));
                    break;
                }
                
                // "で囲まれた部分のテキスト（"を除く）に下線を付けて追加
                string quotedText = text.Substring(quoteStart + 1, quoteEnd - quoteStart - 1);
                System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] \"で囲まれたテキストを検出: {quotedText}");
                
                var run = new Run(quotedText);
                run.TextDecorations = TextDecorations.Underline;
                run.Cursor = Cursors.Hand; // マウスカーソルをポインターに変更
                run.Foreground = new SolidColorBrush(Colors.Blue);
                run.MouseDown += (sender, e) => OnUnderlinedTextClick(quotedText, e);
                textBlock.Inlines.Add(run);
                System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] 下線付きテキストを追加: {quotedText}");
                
                startIndex = quoteEnd + 1;
            }
            
            System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] 検出された\"の数: {quoteCount}, foundQuotes: {foundQuotes}");
            
            // "が見つからなかった場合は通常のテキストとして設定
            if (!foundQuotes)
            {
                System.Diagnostics.Debug.WriteLine("[SetTextWithUnderline] \"が見つからなかったため、通常のテキストとして設定");
                textBlock.Inlines.Clear();
                textBlock.Text = text;
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"[SetTextWithUnderline] 完了: {textBlock.Inlines.Count}個のInline要素を追加");
            }
        }
        
        /// <summary>
        /// 下線付きテキストがクリックされたときに呼び出されます
        /// クリップボードにテキストをコピーします
        /// </summary>
        private void OnUnderlinedTextClick(string text, MouseButtonEventArgs e)
        {
            try
            {
                Clipboard.SetText(text);
                System.Diagnostics.Debug.WriteLine($"[OnUnderlinedTextClick] Copied to clipboard: {text}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[OnUnderlinedTextClick] Error copying to clipboard: {ex.Message}");
                MessageBox.Show($"クリップボードへのコピーに失敗しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void UpdateTaskButtons()
        {
            if (_tasks == null) return;
            
            // 現在のプロジェクトの状態を取得
            int maxTaskCount = _tasks != null ? _tasks.Count : 0;
            bool[] completedStates = _projectTaskCompletedStates.ContainsKey(_currentProjectId) ? 
                _projectTaskCompletedStates[_currentProjectId] : new bool[Math.Max(maxTaskCount, 1)];
            bool[] flaggedStates = _projectTaskFlaggedStates.ContainsKey(_currentProjectId) ? 
                _projectTaskFlaggedStates[_currentProjectId] : new bool[Math.Max(maxTaskCount, 1)];

            // XAMLで定義されているタスクボタンの数（7つ）まで処理
            int maxStaticButtonCount = 7; // XAMLで定義されているボタンの数
            for (int i = 1; i <= maxStaticButtonCount; i++)
            {
                var button = FindName($"TaskButton{i}") as System.Windows.Controls.Button;
                if (button != null)
                {
                    // 現在のプロジェクトのタスク数に応じて表示/非表示を制御
                    bool isVisible = i <= _tasks.Count;
                    button.Visibility = isVisible ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
                    
                    if (isVisible)
                    {
                        UpdateTaskButtonState(button, i, completedStates, flaggedStates);
                    }
                }
            }
            
            // 8つ目以降のタスクボタンを動的に生成（タスク数が7より多い場合）
            var container = FindName("TaskButtonsContainer") as System.Windows.Controls.StackPanel;
            if (container != null && maxTaskCount > maxStaticButtonCount)
            {
                // 既存の動的ボタンを削除
                foreach (var btn in _dynamicTaskButtons)
                {
                    container.Children.Remove(btn);
                }
                _dynamicTaskButtons.Clear();
                
                // TaskButton7のインデックスを取得
                var taskButton7 = FindName("TaskButton7") as System.Windows.Controls.Button;
                int insertIndex = taskButton7 != null ? container.Children.IndexOf(taskButton7) + 1 : container.Children.Count - 1;
                
                // 8つ目以降のボタンを生成
                for (int i = maxStaticButtonCount + 1; i <= maxTaskCount; i++)
                {
                    var button = CreateTaskButton(i);
                    _dynamicTaskButtons.Add(button);
                    
                    // TaskButton7の後に挿入
                    container.Children.Insert(insertIndex, button);
                    insertIndex++; // 次の挿入位置を更新
                }
            }
            else if (container != null && maxTaskCount <= maxStaticButtonCount)
            {
                // タスク数が7以下になった場合は動的ボタンを削除
                foreach (var btn in _dynamicTaskButtons)
                {
                    container.Children.Remove(btn);
                }
                _dynamicTaskButtons.Clear();
            }
            
            // 動的ボタンの状態も更新
            foreach (var button in _dynamicTaskButtons)
            {
                int taskId = (int)button.Tag;
                if (taskId <= maxTaskCount)
                {
                    UpdateTaskButtonState(button, taskId, completedStates, flaggedStates);
                }
            }
        }
        
        private void UpdateTaskButtonState(System.Windows.Controls.Button button, int taskId, bool[] completedStates, bool[] flaggedStates)
        {
            // 数字のTextBlockを更新
            var grid = button.Content as System.Windows.Controls.Grid;
            if (grid != null)
            {
                // 静的ボタン（XAMLで定義）の場合はNameで特定、動的ボタンの場合はTextで判定
                var taskTextBlock = grid.Children.OfType<System.Windows.Controls.TextBlock>()
                    .FirstOrDefault(tb => tb.Name == $"TaskText{taskId}" || (tb.Name == null && tb.Text != "✓" && tb.Text != "🚩"));
                if (taskTextBlock != null)
                {
                    taskTextBlock.Text = taskId.ToString();
                }
                
                // チェックマークの表示制御（タスクIDは1始まり、配列は0始まりなので -1）
                var checkTextBlock = grid.Children.OfType<System.Windows.Controls.TextBlock>()
                    .FirstOrDefault(tb => tb.Name == $"Check{taskId}" || (tb.Name == null && tb.Text == "✓"));
                if (checkTextBlock != null)
                {
                    int arrayIndex = taskId - 1;
                    checkTextBlock.Visibility = (arrayIndex >= 0 && arrayIndex < completedStates.Length && completedStates[arrayIndex]) ? 
                        System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
                }
                
                // 旗マークの表示制御（タスクIDは1始まり、配列は0始まりなので -1）
                var flagTextBlock = grid.Children.OfType<System.Windows.Controls.TextBlock>()
                    .FirstOrDefault(tb => tb.Name == $"Flag{taskId}" || (tb.Name == null && tb.Text == "🚩"));
                if (flagTextBlock != null)
                {
                    int arrayIndex = taskId - 1;
                    flagTextBlock.Visibility = (arrayIndex >= 0 && arrayIndex < flaggedStates.Length && flaggedStates[arrayIndex]) ? 
                        System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
                }
            }
            
            // ボタンの選択状態を更新
            if (taskId == _currentTaskId)
            {
                // 現在のタスクボタンは選択状態
                button.Background = System.Windows.Media.Brushes.White;
                button.BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Gray);
                button.BorderThickness = new System.Windows.Thickness(2);
                button.Foreground = System.Windows.Media.Brushes.Black;
            }
            else
            {
                // 他のタスクボタンは非選択状態
                button.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.LightGray);
                button.BorderThickness = new System.Windows.Thickness(0);
                button.Foreground = System.Windows.Media.Brushes.Black;
            }
        }
        
        private System.Windows.Controls.Button CreateTaskButton(int taskId)
        {
            var button = new System.Windows.Controls.Button
            {
                Width = 120,
                Height = 32,
                Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.LightGray),
                BorderThickness = new System.Windows.Thickness(0),
                Margin = new System.Windows.Thickness(0, 0, 5, 0),
                Tag = taskId
            };
            
            button.Click += TaskButton_Click;
            
            var grid = new System.Windows.Controls.Grid
            {
                Width = 120,
                Height = 32
            };
            
            // タスク番号のTextBlock
            var taskTextBlock = new System.Windows.Controls.TextBlock
            {
                Text = taskId.ToString(),
                FontSize = 16,
                Foreground = System.Windows.Media.Brushes.Black,
                FontWeight = System.Windows.FontWeights.Bold,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                VerticalAlignment = System.Windows.VerticalAlignment.Center
            };
            grid.Children.Add(taskTextBlock);
            
            // チェックマークのTextBlock
            var checkTextBlock = new System.Windows.Controls.TextBlock
            {
                Text = "✓",
                FontSize = 16,
                Foreground = System.Windows.Media.Brushes.Green,
                FontWeight = System.Windows.FontWeights.Bold,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                VerticalAlignment = System.Windows.VerticalAlignment.Center,
                Margin = new System.Windows.Thickness(0, 0, 15, 0),
                Visibility = System.Windows.Visibility.Collapsed
            };
            grid.Children.Add(checkTextBlock);
            
            // 旗マークのTextBlock
            var flagTextBlock = new System.Windows.Controls.TextBlock
            {
                Text = "🚩",
                FontSize = 16,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Center,
                Margin = new System.Windows.Thickness(15, 0, 0, 0),
                Visibility = System.Windows.Visibility.Collapsed
            };
            grid.Children.Add(flagTextBlock);
            
            button.Content = grid;
            
            return button;
        }
        
        
        private void UpdateButtonTexts()
        {
            // 現在のプロジェクトの状態を取得
            int taskCount = _tasks != null ? _tasks.Count : 0;
            bool[] completedStates = _projectTaskCompletedStates.ContainsKey(_currentProjectId) ? 
                _projectTaskCompletedStates[_currentProjectId] : new bool[Math.Max(taskCount, 1)];
            bool[] flaggedStates = _projectTaskFlaggedStates.ContainsKey(_currentProjectId) ? 
                _projectTaskFlaggedStates[_currentProjectId] : new bool[Math.Max(taskCount, 1)];
            
            // 解答済みボタンのテキストを更新
            var completeButton = FindName("CompleteButton") as System.Windows.Controls.Button;
            var completeButtonFooter = FindName("CompleteButtonFooter") as System.Windows.Controls.Button;
            
            if (completeButton != null)
            {
                // タスクIDは1始まり、配列は0始まりなので -1
                int arrayIndex = _currentTaskId - 1;
                if (arrayIndex >= 0 && arrayIndex < completedStates.Length && completedStates[arrayIndex])
                {
                    completeButton.Content = "✓ 解答済み";
                }
                else
                {
                    completeButton.Content = "解答済みにする";
                }
            }
            
            if (completeButtonFooter != null)
            {
                // タスクIDは1始まり、配列は0始まりなので -1
                int arrayIndex = _currentTaskId - 1;
                if (arrayIndex >= 0 && arrayIndex < completedStates.Length && completedStates[arrayIndex])
                {
                    completeButtonFooter.Content = "✓ 解答済み";
                }
                else
                {
                    completeButtonFooter.Content = "解答済みにする";
                }
            }
            
            // フラグボタンのテキストを更新
            var flagButton = FindName("FlagButton") as System.Windows.Controls.Button;
            var flagButtonFooter = FindName("FlagButtonFooter") as System.Windows.Controls.Button;
            
            if (flagButton != null)
            {
                // タスクIDは1始まり、配列は0始まりなので -1
                int arrayIndex = _currentTaskId - 1;
                if (arrayIndex >= 0 && arrayIndex < flaggedStates.Length && flaggedStates[arrayIndex])
                {
                    flagButton.Content = "フラグを外す";
                }
                else
                {
                    flagButton.Content = "あとで見直す";
                }
            }
            
            if (flagButtonFooter != null)
            {
                // タスクIDは1始まり、配列は0始まりなので -1
                int arrayIndex = _currentTaskId - 1;
                if (arrayIndex >= 0 && arrayIndex < flaggedStates.Length && flaggedStates[arrayIndex])
                {
                    flagButtonFooter.Content = "フラグを外す";
                }
                else
                {
                    flagButtonFooter.Content = "あとで見直す";
                }
            }
        }
        
        private void PreviousTask_Click(object sender, RoutedEventArgs e)
        {
            if (_currentTaskId > 1)
            {
                _currentTaskId--;
                UpdateTaskDisplay();
                WriteCurrentTaskFile();
            }
        }
        
        private void NextTask_Click(object sender, RoutedEventArgs e)
        {
            if (_tasks != null && _currentTaskId < _tasks.Count)
            {
                _currentTaskId++;
                UpdateTaskDisplay();
                WriteCurrentTaskFile();
            }
        }
        
        private void TaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button button && button.Tag != null)
            {
                int taskId = int.Parse(button.Tag.ToString());
                if (taskId >= 1 && taskId <= _tasks.Count)
                {
                    _currentTaskId = taskId;
                    UpdateTaskDisplay();
                    WriteCurrentTaskFile();
                }
            }
        }
        
        /// <summary>
        /// VSTO アドインが現在タスクを参照するため、共有ファイルに ProjectId,TaskId を書き出す。
        /// </summary>
        private void WriteCurrentTaskFile()
        {
            try
            {
                string path = Libraries.PPLogReader.GetCurrentTaskFilePath();
                var flags = Libraries.PPTaskValidationConfig.GetExemptFlags(_currentProjectId, _currentTaskId);
                if (_fromResultWindow)
                {
                    EnsureRetryAttemptPrepared(_currentProjectId, _currentTaskId);
                }
                int attemptNo = GetCurrentTaskAttempt(_currentProjectId, _currentTaskId);
                string content = $"{_currentProjectId},{_currentTaskId},{(int)flags},{attemptNo}";
                File.WriteAllText(path, content, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[UiTestAppBarWindow] WriteCurrentTaskFile: " + ex.Message);
            }
        }
        
        private async void NextProject_Click(object sender, RoutedEventArgs e)
        {
            await MoveToNextProjectAsync();
        }
        
        private async Task MoveToNextProjectAsync()
        {
            int maxProjectId = _projectData?.Projects?.Max(p => p.ProjectId) ?? 1;
            // 最終プロジェクトで「次」は「すべて完了」になるため、プレゼン準備オーバーレイは出さない
            if (_currentProjectId >= maxProjectId)
                await MoveToNextProjectCoreAsync();
            else
                await RunWithDelayedPrepareOverlayAsync(MoveToNextProjectCoreAsync);
        }

        private async Task MoveToNextProjectCoreAsync()
        {
            // プロジェクト遷移直前に破壊的操作チェックを完了し、違反があればログに記録（遷移は継続）
            try
            {
                var flags = Libraries.PPTaskValidationConfig.GetExemptFlags(_currentProjectId, _currentTaskId);
                var swDestructive = Stopwatch.StartNew();
                var errors = Libraries.PPSnapshotChecker.CompareAndGetErrors(_currentProjectId, _currentTaskId, flags);
                PPGradingPerf.Log("MoveToNextProject.destructiveSnapshotCheck", swDestructive.ElapsedMilliseconds, $"P{_currentProjectId}-T{_currentTaskId} errCount={errors?.Count ?? 0}");
                if (errors != null && errors.Count > 0)
                {
                    string logPath = Libraries.PPLogReader.GetDestructiveLogPath();
                    string errorMsg = string.Join(" | ", errors);
                    int attemptNo = GetCurrentTaskAttempt(_currentProjectId, _currentTaskId);
                    File.AppendAllText(logPath, $"{_currentProjectId},{_currentTaskId},{attemptNo}:{errorMsg}{Environment.NewLine}");
                    System.Diagnostics.Debug.WriteLine($"[MoveToNextProject] Destructive check failed for {_currentProjectId}-{_currentTaskId}: {errorMsg}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[MoveToNextProject] Destructive check error: {ex.Message}");
            }

            await Dispatcher.Yield(DispatcherPriority.Background);

            // プロジェクト切り替え前にタスク情報をクリアし、アドイン側の破壊的操作チェックをスキップさせる
            Libraries.PPLogReader.ClearCurrentTaskFile();

            await Dispatcher.Yield(DispatcherPriority.Background);

            bool enableProjectBackup = false;
            bool.TryParse(ConfigurationManager.AppSettings["EnableProjectBackup"], out enableProjectBackup);
            if (enableProjectBackup)
            {
                // 現在開いているプレゼンテーションを日付・時間付きバックアップフォルダに保存（MMdd_HHmm）
                string basePath = ConfigurationManager.AppSettings["PowerPointDataPath"] ?? @"C:\MOSTest\PowerPoint365";
                string backupSubdir = DateTime.Now.ToString("MMdd_HHmm");
                string backupFolder = Path.Combine(basePath, $"Tab{_groupId}", "backup", backupSubdir);
                try
                {
                    PowerPointApp pptApp = null;
                    try
                    {
                        pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
                    }
                    catch
                    {
                        // PowerPointが起動していない場合はスキップ
                    }
                    if (pptApp != null && pptApp.Presentations.Count > 0)
                    {
                        if (!Directory.Exists(backupFolder))
                            Directory.CreateDirectory(backupFolder);
                        string backupFilePath = Path.Combine(backupFolder, $"Project{_currentProjectId}.pptx");
                        try
                        {
                            PowerPointPresentation pres = pptApp.Presentations[1];
                            pres.SaveCopyAs(backupFilePath);
                            pres.Save();
                            System.Diagnostics.Debug.WriteLine($"[MoveToNextProject] バックアップ保存: {backupFilePath}");
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine($"[MoveToNextProject] バックアップ保存エラー: {ex.Message}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[MoveToNextProject] バックアップ処理エラー: {ex.Message}");
                }
            }

            await Dispatcher.Yield(DispatcherPriority.Background);

            // プロジェクトの最大数をチェック（JSONファイルの最大プロジェクトID）
            int maxProjectId = _projectData?.Projects?.Max(p => p.ProjectId) ?? 1;

            // 次のプロジェクトに移動
            _currentProjectId++;

            if (_currentProjectId > maxProjectId)
            {
                // 最後のプロジェクトを超えた場合はメッセージを表示
                System.Diagnostics.Debug.WriteLine($"プロジェクト{maxProjectId}を超えました");
                MessageBox.Show("すべてのプロジェクトが完了しました。", "完了", MessageBoxButton.OK, MessageBoxImage.Information);
                ShowReviewPageWindow();
                return;
            }

            await Dispatcher.Yield(DispatcherPriority.Background);

            // 新しいプロジェクトのPowerPointプレゼンテーションを開く
            OpenProjectDocument(_currentProjectId, _groupId);

            // プロジェクト変更時は状態をリセットしない（Dictionaryで管理）

            // 新しいプロジェクトのタスクを読み込み
            LoadCurrentProjectTasks();
            UpdateTaskDisplay();

            // プロジェクトタイマーをリセット
            ResetProjectTimer();

            System.Diagnostics.Debug.WriteLine($"プロジェクト{_currentProjectId}に移動しました");
        }
        
        private void OpenProjectDocument(int projectId, int groupId)
        {
            try
            {
                // MainViewModelと同じロジックでファイルパスを構築
                // App.configからパスを読み込む（存在しない場合はデフォルト値を使用）
                string basePath = ConfigurationManager.AppSettings["PowerPointDataPath"] 
                    ?? @"C:\MOSTest\PowerPoint365";
                string tabFolder = Path.Combine(basePath, $"Tab{groupId}");
                
                // Project1.pptxからProject10.pptxを検索
                string[] possibleNames = { $"Project{projectId}.pptx", $"Project{projectId}.ppt" };
                string filePath = null;
                
                foreach (var fileName in possibleNames)
                {
                    string fullPath = Path.Combine(tabFolder, fileName);
                    if (File.Exists(fullPath))
                    {
                        filePath = fullPath;
                        break;
                    }
                }
                
                if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
                {
                    System.Diagnostics.Debug.WriteLine($"プロジェクト{projectId}のファイルが見つかりません: {tabFolder}");
                    return;
                }

                // 採点スレッドと競合しないよう、閉じる〜開くまでを COM ロックで直列化する
                lock (PowerPointCheckerCommon.PowerPointComInteropSync)
                {
                    // 既に開いているプレゼンテーションがある場合は閉じる（頑健な方法を使用）
                    CloseAllPowerPointPresentations();

                    // プロセスが完全に終了するのを少し待つ
                    Thread.Sleep(500);

                    // PowerPointアプリケーションを取得または作成（CloseAll...でプロセスが終了した可能性があるため、必要に応じて再取得）
                    PowerPointApp pptApp = null;
                    try
                    {
                        pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
                    }
                    catch
                    {
                        pptApp = new PowerPointApp();
                        pptApp.Visible = Microsoft.Office.Core.MsoTriState.msoTrue;
                    }

                    // 新しいプレゼンテーションを開く
                    PowerPointPresentation presentation = null;
                    int retryCount = 0;
                    while (retryCount < 3)
                    {
                        try
                        {
                            presentation = pptApp.Presentations.Open(filePath, WithWindow: Microsoft.Office.Core.MsoTriState.msoTrue);
                            System.Diagnostics.Debug.WriteLine($"プレゼンテーションを開きました: {filePath}");
                            break;
                        }
                        catch (Exception ex)
                        {
                            retryCount++;
                            System.Diagnostics.Debug.WriteLine($"プレゼンテーションを開く際のエラー (試行 {retryCount}/3): {ex.Message}");
                            if (retryCount >= 3)
                            {
                                MessageBox.Show($"プロジェクト{projectId}のファイルを開けませんでした。\nPowerPointを一度終了してから再度お試しください。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                                return;
                            }

                            // 1秒待機してから再試行
                            Thread.Sleep(1000);

                            // PowerPointアプリケーションの状態を確認・再取得
                            try
                            {
                                pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
                            }
                            catch
                            {
                                try { pptApp = new PowerPointApp(); } catch { }
                            }

                            if (pptApp != null)
                                pptApp.Visible = Microsoft.Office.Core.MsoTriState.msoTrue;
                        }
                    }

                    if (presentation == null) return;

                    try
                    {
                        // COMオブジェクトの参照を解放
                        Marshal.ReleaseComObject(presentation);
                    }
                    catch { }

                    // PowerPointウィンドウを画面の上部2/3に配置
                    PositionPowerPointWindow();

                    System.Diagnostics.Debug.WriteLine($"プロジェクト{projectId}のプレゼンテーションを開きました: {filePath}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"プロジェクトプレゼンテーションを開く際のエラー: {ex.Message}");
            }
        }
        
        private async void MoveToNextProjectWithMessage()
        {
            // メッセージを表示
            MessageBox.Show("5分経ったので次のプロジェクトに移動します", "時間切れ", 
                          MessageBoxButton.OK, MessageBoxImage.Information);
            
            // 次のプロジェクトに移動
            await MoveToNextProjectAsync();
        }
        
        private void ResetProjectTimer()
        {
            // プロジェクトタイマーをリセット
            _projectTimer?.Stop();
            _projectStartTime = DateTime.Now;
            _projectTimer?.Start();
        }
        
        private void FlagButton_Click(object sender, RoutedEventArgs e)
        {
            // 現在のプロジェクトの状態を取得または初期化
            if (!_projectTaskFlaggedStates.ContainsKey(_currentProjectId))
            {
                int taskCount = _tasks != null ? _tasks.Count : 0;
                int arraySize = Math.Max(taskCount, 1); // 配列は0始まりなので+1は不要
                _projectTaskFlaggedStates[_currentProjectId] = new bool[arraySize];
            }
            
            bool[] flaggedStates = _projectTaskFlaggedStates[_currentProjectId];
            // タスクIDは1始まり、配列は0始まりなので -1
            int arrayIndex = _currentTaskId - 1;
            
            if (arrayIndex >= 0 && arrayIndex < flaggedStates.Length)
            {
                System.Diagnostics.Debug.WriteLine($"FlagButton_Click: flaggedStates[{arrayIndex}]={flaggedStates[arrayIndex]}, _currentTaskId={_currentTaskId}");
                
                if (!flaggedStates[arrayIndex])
                {
                    // フラグを設定
                    flaggedStates[arrayIndex] = true;
                    System.Diagnostics.Debug.WriteLine($"タスク{_currentTaskId}のフラグを設定しました");
                }
                else
                {
                    // フラグを解除
                    flaggedStates[arrayIndex] = false;
                    System.Diagnostics.Debug.WriteLine($"タスク{_currentTaskId}のフラグを解除しました");
                }
            }
            
            // UIを更新
            UpdateTaskDisplay();
        }
        
        
        private void CompleteButton_Click(object sender, RoutedEventArgs e)
        {
            // 現在のプロジェクトの状態を取得または初期化
            if (!_projectTaskCompletedStates.ContainsKey(_currentProjectId))
            {
                int taskCount = _tasks != null ? _tasks.Count : 0;
                int arraySize = Math.Max(taskCount, 1); // 配列は0始まりなので+1は不要
                _projectTaskCompletedStates[_currentProjectId] = new bool[arraySize];
            }
            
            bool[] completedStates = _projectTaskCompletedStates[_currentProjectId];
            // タスクIDは1始まり、配列は0始まりなので -1
            int arrayIndex = _currentTaskId - 1;
            
            if (arrayIndex >= 0 && arrayIndex < completedStates.Length)
            {
                System.Diagnostics.Debug.WriteLine($"CompleteButton_Click: completedStates[{arrayIndex}]={completedStates[arrayIndex]}, _currentTaskId={_currentTaskId}");
                
                if (!completedStates[arrayIndex])
                {
                    // チェックマークを設定
                    completedStates[arrayIndex] = true;
                    System.Diagnostics.Debug.WriteLine($"タスク{_currentTaskId}のチェックマークを設定しました");
                }
                else
                {
                    // チェックマークを解除
                    completedStates[arrayIndex] = false;
                    System.Diagnostics.Debug.WriteLine($"タスク{_currentTaskId}のチェックマークを解除しました");
                }
            }
            
            // UIを更新
            UpdateTaskDisplay();
        }
        
        
        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = MessageBox.Show(
                    $"プロジェクト{_currentProjectId}をリセットしますか？\n現在の変更内容は失われます。",
                    "リセット確認",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);
                
                if (result == MessageBoxResult.Yes)
                {
                    // リセット前にスナップショットをクリアし、アドイン側に再取得を促す
                    Libraries.PPLogReader.ClearSnapshot();
                    ResetProject(_groupId, _currentProjectId);
                    PowerPointChecker1_1.ResetTask4SlideDeletionState();
                    MessageBox.Show("プロジェクトをリセットしました。", "リセット完了", MessageBoxButton.OK, MessageBoxImage.Information);
                    
                    // リセット後、PowerPointプレゼンテーションを再読み込み
                    OpenProjectDocument(_currentProjectId, _groupId);
                    WriteCurrentTaskFile();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[ResetButton_Click] Error: {ex.Message}");
                MessageBox.Show($"リセット中にエラーが発生しました: {ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void ResetProject(int groupId, int projectId)
        {
            CloseAllPowerPointPresentations();
            MOS_PowerPoint_app.PowerPointProjectResetHelper.ResetProject(groupId, projectId);
        }
        
        /// <summary>
        /// 開いているすべてのPowerPointプレゼンテーションを保存する（閉じない）。
        /// </summary>
        private void SaveAllPowerPointPresentations()
        {
            try
            {
                lock (PowerPointCheckerCommon.PowerPointComInteropSync)
                {
                    PowerPointApp pptApp = null;
                    try
                    {
                        pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
                    }
                    catch
                    {
                        System.Diagnostics.Debug.WriteLine("[SaveAllPowerPointPresentations] PowerPointアプリケーションが見つかりません");
                        return;
                    }
                    for (int i = 1; i <= pptApp.Presentations.Count; i++)
                    {
                        try
                        {
                            var pres = pptApp.Presentations[i];
                            pres.Save();
                            System.Diagnostics.Debug.WriteLine($"[SaveAllPowerPointPresentations] 保存しました: {pres.Name}");
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine($"[SaveAllPowerPointPresentations] 保存エラー: {ex.Message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[SaveAllPowerPointPresentations] Error: {ex.Message}");
            }
        }

        /// <summary>Presentations.Count 取得時の COM 例外を握りつぶす（切断直後など）。</summary>
        private static int GetPresentationCountSafe(PowerPointApp pptApp)
        {
            if (pptApp == null) return 0;
            try
            {
                return pptApp.Presentations.Count;
            }
            catch (COMException)
            {
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        private void CloseAllPowerPointPresentations()
        {
            try
            {
                lock (PowerPointCheckerCommon.PowerPointComInteropSync)
                {
                PowerPointApp pptApp = null;
                try
                {
                    pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
                }
                catch
                {
                    // PowerPointが起動していない場合は何もしない
                    System.Diagnostics.Debug.WriteLine("[CloseAllPowerPointPresentations] PowerPointアプリケーションが見つかりません");
                    return;
                }
                
                // すべてのプレゼンテーションを閉じる（無限ループ防止: 最大試行回数と Count が減らない場合の打ち切り）
                // 注意: Close() 後は openPres は無効になるため、名前は必ず閉じる前に取得すること。
                const int maxAttempts = 25;
                int prevCount = GetPresentationCountSafe(pptApp);
                for (int attempt = 0; attempt < maxAttempts && GetPresentationCountSafe(pptApp) > 0; attempt++)
                {
                    PowerPointPresentation openPres = null;
                    try
                    {
                        openPres = pptApp.Presentations[1]; // 1-based index
                        string presName = "(不明)";
                        try { presName = openPres.Name; } catch { }

                        try
                        {
                            openPres.Save();
                            System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] プレゼンテーションを保存しました: {presName}");
                        }
                        catch { }

                        try
                        {
                            openPres.Close();
                        }
                        catch (COMException comClose)
                        {
                            System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] Close で COM: {comClose.Message}");
                        }

                        System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] プレゼンテーションを閉じました: {presName}");

                        int newCount = GetPresentationCountSafe(pptApp);
                        if (newCount >= prevCount)
                        {
                            System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] Countが減らないため、強制的にプロセスを終了します。 (prev={prevCount}, new={newCount})");
                            try
                            {
                                var pptProcesses = System.Diagnostics.Process.GetProcessesByName("POWERPNT");
                                foreach (var proc in pptProcesses) 
                                { 
                                    try { proc.Kill(); proc.WaitForExit(2000); } catch { } 
                                }
                            }
                            catch { }
                            break;
                        }
                        prevCount = newCount;
                    }
                    catch (COMException comEx) when (comEx.HResult == unchecked((int)0x80010108)) // RPC_E_DISCONNECTED
                    {
                        System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] プレゼンテーションは既に切断されています（無視）: {comEx.Message}");
                        break;
                    }
                    catch (COMException comEx)
                    {
                        // オブジェクトは存在しません 等、Close 前後の切断
                        System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] COM: {comEx.Message} (0x{comEx.HResult:X8})");
                        if (GetPresentationCountSafe(pptApp) <= 0)
                            break;
                    }
                    catch (Exception closeEx)
                    {
                        System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] プレゼンテーションを閉じる際のエラー: {closeEx.Message}");
                        if (GetPresentationCountSafe(pptApp) > 0)
                        {
                            try
                            {
                                var nextPres = pptApp.Presentations[1];
                                if (nextPres == openPres)
                                    break;
                                try { Marshal.ReleaseComObject(nextPres); } catch { }
                            }
                            catch
                            {
                                break;
                            }
                        }
                    }
                    finally
                    {
                        try
                        {
                            if (openPres != null)
                            {
                                Marshal.ReleaseComObject(openPres);
                            }
                        }
                        catch { }
                    }
                }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[CloseAllPowerPointPresentations] Error: {ex.Message}");
            }
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _timer?.Stop();
            _projectTimer?.Stop();
            _slideMonitorTimer?.Stop();
            // ウィンドウを閉じる際にタスク情報をクリアし、次回起動時に古い情報でチェックが走るのを防ぐ
            Libraries.PPLogReader.ClearCurrentTaskFile();
            base.OnClosed(e);
        }
        /// <summary>
        /// アプリバー側のプロジェクト変更を MainViewModel 側に同期させます。
        /// これにより、採点時に正しいプロジェクトのタスク一覧が使用されるようになります。
        /// </summary>
        private void SyncProjectToMainViewModel()
        {
            try
            {
                var mainWin = System.Windows.Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
                if (mainWin != null && mainWin.DataContext is MainViewModel vm)
                {
                    // 現在の GroupId と ProjectId に一致するプロジェクトを検索
                    var project = vm.ProjectGroups
                        .FirstOrDefault(g => g.GroupId == _groupId)?
                        .Projects.FirstOrDefault(p => p.ProjectId == _currentProjectId);

                    if (project != null)
                    {
                        vm.CurrentProject = project;
                        System.Diagnostics.Debug.WriteLine($"[Sync] MainViewModel のプロジェクトを更新しました: {project.Name}");
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[Sync] 同期エラー: {ex.Message}");
            }
        }

        private static string GetTaskKey(int projectId, int taskId)
        {
            return $"{projectId}-{taskId}";
        }

        private static int GetCurrentTaskAttempt(int projectId, int taskId)
        {
            return Libraries.PPTaskAttemptRegistry.GetAttempt(projectId, taskId);
        }

        private bool EnsureRetryAttemptPrepared(int projectId, int taskId)
        {
            string key = GetTaskKey(projectId, taskId);
            if (!_initialWrongTaskKeys.Contains(key))
                return false;
            if (_preparedRetryTaskKeys.Contains(key))
                return true;

            int currentAttempt = GetCurrentTaskAttempt(projectId, taskId);
            Libraries.PPTaskAttemptRegistry.SetAttempt(projectId, taskId, currentAttempt + 1);
            _retryTaskKeys.Add(key);
            _preparedRetryTaskKeys.Add(key);
            System.Diagnostics.Debug.WriteLine($"[RetryAttempt] Started for {key}, attempt={GetCurrentTaskAttempt(projectId, taskId)}");
            return true;
        }

        private void TryRescorePendingRetryTasks()
        {
            if (_retryTaskKeys.Count == 0)
                return;

            var keysToScore = _retryTaskKeys.ToList();
            var resultWindow = _resultWindow ?? System.Windows.Application.Current.Windows.OfType<ResultWindow>().FirstOrDefault();
            if (resultWindow == null)
                return;

            foreach (var key in keysToScore)
            {
                if (!TryParseTaskKey(key, out int projectId, out int taskId))
                    continue;

                int attemptNo = GetCurrentTaskAttempt(projectId, taskId);
                bool? passed = null;
                bool isError = false;
                try
                {
                    using (var grader = new PowerPointGrader())
                    {
                        if (!grader.Connect())
                        {
                            isError = true;
                        }
                        else
                        {
                            grader.StartTaskAndWaitForSnapshot(projectId, taskId, attemptNo, 2000, 50);
                            passed = grader.GradeTask(projectId, taskId, attemptNo);
                        }
                    }
                }
                catch (Exception ex)
                {
                    isError = true;
                    System.Diagnostics.Debug.WriteLine($"[RetryAttempt] Rescore error for {key}: {ex.Message}");
                }

                resultWindow.ApplyRetryScoreResult(projectId, taskId, passed, isError);
                if (!isError)
                    _retryTaskKeys.Remove(key);
            }
        }

        private static bool TryParseTaskKey(string key, out int projectId, out int taskId)
        {
            projectId = -1;
            taskId = -1;
            if (string.IsNullOrWhiteSpace(key))
                return false;
            var parts = key.Split('-');
            if (parts.Length != 2)
                return false;
            return int.TryParse(parts[0], out projectId) && int.TryParse(parts[1], out taskId);
        }
    }
    
    public class ProjectData
    {
        public List<ProjectInfo> Projects { get; set; }
    }
    
    public class ProjectInfo
    {
        public int ProjectId { get; set; }
        public List<TaskInfo> Tasks { get; set; }
    }
    
    public class TaskInfo
    {
        public int TaskId { get; set; }
        public string Description { get; set; }
    }
}


