using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PowerPointApp = Microsoft.Office.Interop.PowerPoint.Application;
using PowerPointPresentation = Microsoft.Office.Interop.PowerPoint.Presentation;
using Microsoft.Office.Interop.PowerPoint;
using Microsoft.Office.Core;

namespace MOS_PowerPoint_app
{
    public class ProjectInfo
    {
        public string Name { get; set; }
        public string FilePath { get; set; }
        public string Group { get; set; }
        public int ProjectNumber { get; set; }
    }

    public class MainViewModel : INotifyPropertyChanged
    {
        private int _selectedTabIndex;
        private string _resultMessage;
        private bool _showScoreButton;
        private bool _showPauseButton;
        private bool _showScoreResult = true;
        private ProjectViewModel _currentProject;
        private ObservableCollection<TaskResult> _taskResults;
        private int _totalScore;
        private int _maxScore;

        public MainViewModel()
        {
            LoadProjects();
            OpenProjectCommand = new RelayCommand(ExecuteOpenProject);
            UiTestCommand = new RelayCommand(ExecuteUiTest);
            ScoreCommand = new RelayCommand(ExecuteScore, CanExecuteScore);
            ResetAllProjectsCommand = new RelayCommand(ExecuteResetAllProjects);
            TaskResults = new ObservableCollection<TaskResult>();
        }

        public ObservableCollection<ProjectGroupViewModel> ProjectGroups { get; set; } = new ObservableCollection<ProjectGroupViewModel>();

        public int SelectedTabIndex
        {
            get => _selectedTabIndex;
            set
            {
                _selectedTabIndex = value;
                OnPropertyChanged();
            }
        }

        public string ResultMessage
        {
            get => _resultMessage;
            set
            {
                _resultMessage = value;
                OnPropertyChanged();
            }
        }

        public ICommand OpenProjectCommand { get; }
        public ICommand UiTestCommand { get; }
        public ICommand ScoreCommand { get; }
        public ICommand ResetAllProjectsCommand { get; }

        public ProjectViewModel CurrentProject
        {
            get => _currentProject;
            set
            {
                _currentProject = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CurrentProjectName));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        /// <summary>採点ボタンをアプリバーに表示するか。デフォルトは非表示。</summary>
        public bool ShowScoreButton
        {
            get => _showScoreButton;
            set { _showScoreButton = value; OnPropertyChanged(nameof(ShowScoreButton)); }
        }

        /// <summary>一時停止ボタンをアプリバーに表示するか。デフォルトは非表示。</summary>
        public bool ShowPauseButton
        {
            get => _showPauseButton;
            set { _showPauseButton = value; OnPropertyChanged(nameof(ShowPauseButton)); }
        }

        /// <summary>採点結果（タスク別一覧）を表示するか。チェックONで採点ロジックを確認できる。</summary>
        public bool ShowScoreResult
        {
            get => _showScoreResult;
            set { _showScoreResult = value; OnPropertyChanged(nameof(ShowScoreResult)); }
        }

        public string CurrentProjectName => CurrentProject?.Name ?? "";

        public event EventHandler ShowAppBarRequested;
        public event EventHandler HideMainWindowRequested;
        /// <summary>採点完了時に発火。採点結果ダイアログの表示に使用する。</summary>
        public event EventHandler ScoreCompleted;
#pragma warning disable 67 // イベントは外部で使用されるため警告を抑制
        public event EventHandler ShowMainWindowRequested;
        public event EventHandler ExamEnded;
#pragma warning restore 67

        public ObservableCollection<TaskResult> TaskResults
        {
            get => _taskResults;
            set
            {
                _taskResults = value;
                OnPropertyChanged();
            }
        }

        public int TotalScore
        {
            get => _totalScore;
            set
            {
                _totalScore = value;
                OnPropertyChanged();
            }
        }

        public int MaxScore
        {
            get => _maxScore;
            set
            {
                _maxScore = value;
                OnPropertyChanged();
            }
        }

        private void LoadProjects()
        {
            try
            {
                // 優先順位1: Assets\config.json（mos_xaml_app と同様に、ClickOnceでも同梱しやすい）
                // 優先順位2: App.config の appSettings
                // 優先順位3: 既定値
                string basePath = null;

                try
                {
                    string configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "config.json");
                    if (File.Exists(configPath))
                    {
                        string jsonContent = File.ReadAllText(configPath);
                        JObject config = JObject.Parse(jsonContent);
                        basePath = config["powerPointDataPath"]?.ToString();
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Assets\\config.json 読み込みエラー: {ex.Message}");
                }

                if (string.IsNullOrWhiteSpace(basePath))
                {
                    basePath = ConfigurationManager.AppSettings["PowerPointDataPath"];
                }

                if (string.IsNullOrWhiteSpace(basePath))
                {
                    basePath = @"C:\MOSTest\PowerPoint365";
                }
                
                // Tab1, Tab3のフォルダからプロジェクトを読み込む（模試①=Tab2は非表示のためスキップ）
                foreach (int groupId in new[] { 1, 3 })
                {
                    string tabFolder = Path.Combine(basePath, $"Tab{groupId}");
                    var group = new ProjectGroupViewModel { GroupId = groupId, GroupName = groupId == 3 ? "応用編" : $"Group {groupId}" };
                    
                    if (Directory.Exists(tabFolder))
                    {
                        // Project1.pptxからProject11.pptxを検索
                        for (int projectId = 1; projectId <= 11; projectId++)
                        {
                            // Project1.pptx, Project2.pptx, ... を検索
                            string[] possibleNames = { $"Project{projectId}.pptx", $"Project{projectId}.ppt" };
                            string filePath = null;
                            
                            foreach (var fileName in possibleNames)
                            {
                                string fullPath = Path.Combine(tabFolder, fileName);
                                if (File.Exists(fullPath))
                                {
                                    filePath = fullPath;
                                    break;
                                }
                            }
                            
                            group.Projects.Add(new ProjectViewModel
                            {
                                GroupId = groupId,
                                ProjectId = projectId,
                                Name = $"プロジェクト{groupId}-{projectId}",
                                FilePath = filePath
                            });
                        }
                    }
                    else
                    {
                        // フォルダが存在しない場合でも、空のプロジェクトリストを作成
                        for (int projectId = 1; projectId <= 11; projectId++)
                        {
                            group.Projects.Add(new ProjectViewModel
                            {
                                GroupId = groupId,
                                ProjectId = projectId,
                                Name = $"プロジェクト{groupId}-{projectId}",
                                FilePath = null
                            });
                        }
                    }
                    
                    ProjectGroups.Add(group);
                }
            }
            catch (Exception ex)
            {
                // 例外をログに記録するが、アプリを継続させる
                System.Diagnostics.Debug.WriteLine($"LoadProjectsエラー: {ex.Message}");
                // 空のプロジェクトグループを作成してアプリを継続（模試①=Group2はスキップ）
                foreach (int groupId in new[] { 1, 3 })
                {
                    var group = new ProjectGroupViewModel { GroupId = groupId, GroupName = groupId == 3 ? "応用編" : $"Group {groupId}" };
                    for (int projectId = 1; projectId <= 11; projectId++)
                    {
                        group.Projects.Add(new ProjectViewModel
                        {
                            GroupId = groupId,
                            ProjectId = projectId,
                            Name = $"プロジェクト{groupId}-{projectId}",
                            FilePath = null
                        });
                    }
                    ProjectGroups.Add(group);
                }
            }
        }

        private void ExecuteOpenProject(object parameter)
        {
            if (parameter is ProjectViewModel project)
            {
                if (string.IsNullOrEmpty(project.FilePath) || !File.Exists(project.FilePath))
                {
                    ResultMessage = $"エラー: ファイルが見つかりません: {project.FilePath ?? "パスが設定されていません"}";
                    return;
                }

                try
                {
                    // プロジェクト起動前にタスク情報をクリアし、アドイン側の古いスナップショットとの比較を防止
                    Libraries.PPLogReader.ClearCurrentTaskFile();

                    // PowerPointアプリケーションを取得または作成
                    PowerPointApp pptApp = null;
                    try
                    {
                        pptApp = (PowerPointApp)Marshal.GetActiveObject("PowerPoint.Application");
                    }
                    catch
                    {
                        pptApp = new PowerPointApp();
                        pptApp.Visible = MsoTriState.msoTrue;
                    }

                    try
                    {
                        pptApp.Presentations.Open(project.FilePath, WithWindow: MsoTriState.msoTrue);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"プレゼンテーションを開く際のエラー（既に開いている可能性があります）: {ex.Message}");
                    }

                    CurrentProject = project;
                    HideMainWindowRequested?.Invoke(this, EventArgs.Empty);
                    ShowAppBarRequested?.Invoke(this, EventArgs.Empty);
                    ResultMessage = $"PowerPointファイルを開きました: {Path.GetFileName(project.FilePath)}";
                }
                catch (Exception ex)
                {
                    ResultMessage = $"エラー: ファイルを開けませんでした: {ex.Message}";
                    System.Diagnostics.Debug.WriteLine($"エラー詳細: {ex.StackTrace}");
                }
            }
        }

        private void ExecuteUiTest(object parameter)
        {
            ResultMessage = "UIテスト機能は準備中です";
        }

        private bool CanExecuteScore(object parameter)
        {
            return CurrentProject != null;
        }

        private void ExecuteScore(object parameter)
        {
            if (CurrentProject == null)
            {
                ResultMessage = "プロジェクトを開いてから実行してください。";
                return;
            }

            TaskResults.Clear();
            ResultMessage = "採点中...";

            string jsonPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MOS模擬アプリ問題文一覧_PowerPoint.json");
            if (!File.Exists(jsonPath))
                jsonPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "References", "JSON", "MOS模擬アプリ問題文一覧_PowerPoint.json");
            if (!File.Exists(jsonPath))
            {
                ResultMessage = "該当プロジェクトのタスクが見つかりません（問題文JSONがありません）。";
                return;
            }

            MOS_PowerPoint_app.Views.ProjectData projectData;
            try
            {
                string jsonContent = File.ReadAllText(jsonPath, Encoding.UTF8);
                projectData = JsonConvert.DeserializeObject<MOS_PowerPoint_app.Views.ProjectData>(jsonContent);
            }
            catch (Exception ex)
            {
                ResultMessage = $"問題文の読み込みに失敗しました: {ex.Message}";
                return;
            }

            var project = projectData?.Projects?.FirstOrDefault(p => p.ProjectId == CurrentProject.ProjectId);
            if (project?.Tasks == null || project.Tasks.Count == 0)
            {
                ResultMessage = "該当プロジェクトのタスクが見つかりません。";
                return;
            }

            PowerPointGrader grader = null;
            try
            {
                grader = new PowerPointGrader();
                if (!grader.Connect())
                {
                    ResultMessage = "PowerPoint を起動し、対象のファイルを開いた状態で実行してください。";
                    return;
                }

                int passedCount = 0;
                foreach (var task in project.Tasks.OrderBy(t => t.TaskId))
                {
                    bool passed = false;
                    try
                    {
                        // 1タスクごとに current_task を更新し、VSTO 側の snapshot が追いつくのを短時間待つ。
                        int attemptNo = Libraries.PPTaskAttemptRegistry.GetAttempt(CurrentProject.ProjectId, task.TaskId);
                        grader.StartTaskAndWaitForSnapshot(CurrentProject.ProjectId, task.TaskId, attemptNo, 2000, 50);
                        passed = grader.GradeTask(CurrentProject.ProjectId, task.TaskId, attemptNo);
                    }
                    catch
                    {
                        passed = false;
                    }
                    if (passed) passedCount++;
                    TaskResults.Add(new TaskResult
                    {
                        TaskNumber = task.TaskId,
                        IsPassed = passed,
                        TaskName = string.IsNullOrEmpty(task.Description) ? $"タスク{task.TaskId}" : task.Description
                    });
                }
                ResultMessage = $"採点: {passedCount}/{project.Tasks.Count} タスク合格";
                ScoreCompleted?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                ResultMessage = $"採点中にエラーが発生しました: {ex.Message}";
            }
            finally
            {
                grader?.Dispose();
            }
        }

        private void ExecuteResetAllProjects(object parameter)
        {
            var result = MessageBox.Show(
                "すべてのPowerPointプロジェクトをテンプレートからリセットします。\n現在の変更内容は失われます。実行しますか？",
                "すべてをリセットする",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
                return;

            try { Libraries.PPTaskAttemptRegistry.ClearAll(); } catch { }

            // 全プロジェクトリセット時のみ採点用証跡も消す（単体リセットでは残す）
            try { Libraries.PPLogReader.ClearTaskEvidence(); } catch { }

            var errors = new System.Collections.Generic.List<string>();
            int done = 0;
            foreach (int groupId in new[] { 1 }) // Tab1のみリセットし、Tab3（応用編）は除外
            {
                for (int projectId = 1; projectId <= 11; projectId++)
                {
                    try
                    {
                        PowerPointProjectResetHelper.ResetProject(groupId, projectId);
                        done++;
                    }
                    catch (Exception ex)
                    {
                        errors.Add($"Tab{groupId} Project{projectId}: {ex.Message}");
                    }
                }
            }

            if (errors.Count == 0)
                ResultMessage = $"すべてのプロジェクトをリセットしました（{done}件）。";
            else
                ResultMessage = $"{done}件リセットしました。失敗: {errors.Count}件";
            MessageBox.Show(
                errors.Count == 0
                    ? $"すべてのプロジェクトをリセットしました（{done}件）。"
                    : $"{done}件リセットしました。\n失敗 {errors.Count}件:\n" + string.Join("\n", errors.Take(10)) + (errors.Count > 10 ? "\n…他" : ""),
                "リセット結果",
                MessageBoxButton.OK,
                errors.Count == 0 ? MessageBoxImage.Information : MessageBoxImage.Warning);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ProjectGroupViewModel
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public ObservableCollection<ProjectViewModel> Projects { get; set; } = new ObservableCollection<ProjectViewModel>();
    }

    public class ProjectViewModel
    {
        public int GroupId { get; set; }
        public int ProjectId { get; set; }
        public string Name { get; set; }
        public string FilePath { get; set; }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute?.Invoke(parameter) ?? true;
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }

    public class TaskResult
    {
        public int TaskNumber { get; set; }
        public bool IsPassed { get; set; }
        public string TaskName { get; set; }
    }
}
